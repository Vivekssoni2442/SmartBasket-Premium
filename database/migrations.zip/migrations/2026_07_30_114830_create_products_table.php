<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up(): void
{
    Schema::create('products', function (Blueprint $table) {

        $table->id();

        $table->string('name');

        $table->string('category');

        $table->text('description')->nullable();

        $table->string('image')->nullable();

        $table->decimal('price',10,2);

        $table->decimal('rating',2,1)->default(4.5);

        $table->integer('stock')->default(100);

        $table->timestamps();

    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
