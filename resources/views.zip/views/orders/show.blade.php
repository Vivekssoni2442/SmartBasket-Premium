<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Order #{{ $order->id }} | SMART BASKET
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <style>

        /* ==========================================================
           SMART BASKET ORDER PAGE
        ========================================================== */

        :root {

            --order-bg: #f5f8fc;
            --order-bg-secondary: #eef3f9;
            --order-card: #ffffff;
            --order-surface: #f8fafc;

            --order-text: #334155;
            --order-heading: #0f172a;
            --order-muted: #64748b;

            --order-border: rgba(15,23,42,.09);
            --order-border-strong: rgba(37,99,235,.18);

            --order-primary: #2563eb;
            --order-primary-hover: #1d4ed8;
            --order-primary-soft: rgba(37,99,235,.08);

            --order-purple: #6366f1;

            --order-success: #16a34a;
            --order-warning: #f59e0b;
            --order-danger: #dc2626;

            --topbar-bg: #07111f;
            --topbar-border: rgba(59,130,246,.18);

            --order-shadow:
                0 20px 60px rgba(15,23,42,.09);

            --order-header-shadow:
                0 25px 75px rgba(15,23,42,.11);
        }


        /* ==========================================================
           DARK THEME
        ========================================================== */

        html[data-sb-theme="dark"],
        body[data-sb-theme="dark"] {

            --order-bg: #050b18;
            --order-bg-secondary: #081120;
            --order-card: #0b1426;
            --order-surface: #101d33;

            --order-text: #cbd5e1;
            --order-heading: #f8fbff;
            --order-muted: #94a3b8;

            --order-border: rgba(96,165,250,.15);
            --order-border-strong: rgba(59,130,246,.35);

            --order-primary: #3b82f6;
            --order-primary-hover: #60a5fa;
            --order-primary-soft: rgba(59,130,246,.12);

            --order-purple: #6366f1;

            --order-success: #22c55e;
            --order-warning: #f59e0b;
            --order-danger: #ef4444;

            --topbar-bg: #030914;
            --topbar-border: rgba(59,130,246,.22);

            --order-shadow:
                0 25px 80px rgba(0,0,0,.52);

            --order-header-shadow:
                0 30px 90px rgba(0,0,0,.60);
        }


        /* ==========================================================
           RESET
        ========================================================== */

        * {
            box-sizing: border-box;
        }


        html,
        body {

            margin: 0;
            padding: 0;

            min-height: 100%;

            scroll-behavior: smooth;
        }


        /* ==========================================================
           BODY
        ========================================================== */

        body {

            color: var(--order-text);

            font-family:
                Inter,
                system-ui,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background: var(--order-bg);

            transition:
                background .3s ease,
                color .3s ease;

            /*
            Top taskbar ki height ke liye space.
            */
            padding-top: 79px;
        }


        /* ==========================================================
           BACKGROUND
        ========================================================== */

        html[data-sb-theme="light"] body,
        body[data-sb-theme="light"] {

            background:

                radial-gradient(
                    circle at 5% 0%,
                    rgba(37,99,235,.10),
                    transparent 30%
                ),

                radial-gradient(
                    circle at 95% 5%,
                    rgba(99,102,241,.08),
                    transparent 30%
                ),

                var(--order-bg);
        }


        html[data-sb-theme="dark"] body,
        body[data-sb-theme="dark"] {

            background:

                radial-gradient(
                    circle at 8% 0%,
                    rgba(37,99,235,.20),
                    transparent 30%
                ),

                radial-gradient(
                    circle at 92% 8%,
                    rgba(59,130,246,.11),
                    transparent 28%
                ),

                radial-gradient(
                    circle at 50% 100%,
                    rgba(30,64,175,.08),
                    transparent 35%
                ),

                #050b18;
        }


        /* ==========================================================
           ==========================================================
           TOP SMART BASKET TASKBAR
           ==========================================================
        ========================================================== */

        .sb-topbar {

            position: fixed;

            top: 0;
            left: 0;
            right: 0;

            z-index: 999999;

            height: 79px;

            display: flex;

            align-items: center;

            gap: 12px;

            padding:
                10px 18px;

            background:
                linear-gradient(
                    180deg,
                    #081426 0%,
                    #07111f 100%
                );

            border-bottom:
                1px solid
                rgba(59,130,246,.18);

            box-shadow:
                0 10px 35px
                rgba(0,0,0,.28);

            transition:
                background .3s ease,
                border-color .3s ease;
        }


        .sb-topbar::after {

            content: "";

            position: absolute;

            left: 0;
            right: 0;

            bottom: 0;

            height: 2px;

            background:
                linear-gradient(
                    90deg,
                    #2563eb,
                    #6366f1,
                    #ec4899
                );
        }


        /* ==========================================================
           BRAND
        ========================================================== */

        .sb-brand {

            width: 198px;

            min-width: 198px;

            height: 56px;

            display: flex;

            align-items: center;

            gap: 11px;

            text-decoration: none;

            color: #ffffff;

            padding-left: 1px;
        }


        .sb-brand-logo {

            width: 45px;

            height: 45px;

            flex-shrink: 0;

            display: grid;

            place-items: center;

            border-radius: 14px;

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5
                );

            box-shadow:
                0 10px 25px
                rgba(37,99,235,.35);

            font-size: 20px;
        }


        .sb-brand-content {

            min-width: 0;
        }


        .sb-brand-title {

            color: #ffffff;

            font-size: 14px;

            font-weight: 950;

            letter-spacing: .2px;

            white-space: nowrap;
        }


        .sb-brand-subtitle {

            margin-top: 2px;

            color: #94a3b8;

            font-size: 8px;

            font-weight: 900;

            letter-spacing: 1.3px;

            white-space: nowrap;
        }


        /* ==========================================================
           TOP NAVIGATION
        ========================================================== */

        .sb-topnav {

            flex: 1;

            min-width: 0;

            display: flex;

            align-items: center;

            gap: 6px;
        }


        .sb-nav-item {

            height: 50px;

            flex: 1;

            min-width: 105px;

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 9px;

            padding:
                0 14px;

            border:
                1px solid
                rgba(59,130,246,.18);

            border-radius: 14px;

            color: #94a3b8;

            background:
                rgba(7,22,42,.78);

            text-decoration: none;

            font-size: 12px;

            font-weight: 850;

            white-space: nowrap;

            transition:
                color .2s ease,
                background .2s ease,
                border-color .2s ease,
                transform .2s ease,
                box-shadow .2s ease;
        }


        .sb-nav-item i {

            font-size: 13px;

            opacity: .95;
        }


        .sb-nav-item:hover {

            color: #ffffff;

            background:
                rgba(37,99,235,.16);

            border-color:
                rgba(59,130,246,.45);

            transform:
                translateY(-1px);

            box-shadow:
                0 8px 22px
                rgba(37,99,235,.12);
        }


        .sb-nav-item.active {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5
                );

            border-color:
                rgba(96,165,250,.50);

            box-shadow:
                0 10px 28px
                rgba(37,99,235,.28);
        }


        /* ==========================================================
           AI HUB
        ========================================================== */

        .sb-nav-item.ai-hub {

            color: #3b82f6;
        }


        .sb-nav-item.ai-hub:hover {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5
                );

            border-color:
                rgba(96,165,250,.65);

            box-shadow:
                0 10px 30px
                rgba(37,99,235,.32);
        }


        /* ==========================================================
           SMART AI
        ========================================================== */

        .sb-smart-ai {

            height: 50px;

            min-width: 150px;

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 9px;

            padding:
                0 15px;

            border:
                1px solid
                rgba(59,130,246,.18);

            border-radius: 14px;

            color: #94a3b8;

            background:
                rgba(7,22,42,.78);

            cursor: pointer;

            font-size: 11px;

            font-weight: 900;

            white-space: nowrap;

            transition:
                all .2s ease;
        }


        .sb-smart-ai:hover {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5
                );

            border-color:
                rgba(96,165,250,.65);

            transform:
                translateY(-1px);

            box-shadow:
                0 10px 30px
                rgba(37,99,235,.35);
        }


        .sb-smart-ai-icon {

            width: 28px;

            height: 28px;

            display: grid;

            place-items: center;

            border-radius: 9px;

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #7c3aed,
                    #4f46e5
                );

            box-shadow:
                0 5px 15px
                rgba(124,58,237,.30);
        }


        .sb-smart-ai:hover .sb-smart-ai-icon {

            background:
                rgba(255,255,255,.20);
        }


        .sb-ai-online-dot {

            position: absolute;

            width: 7px;

            height: 7px;

            margin:
                -26px 0 0 125px;

            border-radius: 50%;

            background: #22c55e;

            border:
                2px solid
                #07111f;

            box-shadow:
                0 0 10px
                rgba(34,197,94,.65);
        }


        /* ==========================================================
           USER BOX
        ========================================================== */

        .sb-user-box {

            height: 50px;

            min-width: 145px;

            display: flex;

            align-items: center;

            gap: 9px;

            padding:
                0 13px;

            border:
                1px solid
                rgba(59,130,246,.22);

            border-radius: 14px;

            color: #ffffff;

            background:
                rgba(7,22,42,.88);
        }


        .sb-user-icon {

            width: 30px;

            height: 30px;

            display: grid;

            place-items: center;

            flex-shrink: 0;

            border-radius: 9px;

            color: #60a5fa;

            border:
                1px solid
                rgba(59,130,246,.25);

            background:
                rgba(37,99,235,.10);
        }


        .sb-user-text {

            min-width: 0;
        }


        .sb-user-hi {

            color: #94a3b8;

            font-size: 8px;

            font-weight: 800;
        }


        .sb-user-name {

            margin-top: 2px;

            color: #ffffff;

            font-size: 10px;

            font-weight: 950;

            text-transform: uppercase;

            white-space: nowrap;

            overflow: hidden;

            text-overflow: ellipsis;
        }


        /* ==========================================================
           3 DOT BUTTON
        ========================================================== */

        .sb-three-dot-btn {

            width: 54px;

            height: 50px;

            flex-shrink: 0;

            display: grid;

            place-items: center;

            border:
                1px solid
                rgba(59,130,246,.25);

            border-radius: 14px;

            color: #dbeafe;

            background:
                rgba(7,22,42,.90);

            cursor: pointer;

            transition:
                all .22s ease;
        }


        .sb-three-dot-btn:hover {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5
                );

            border-color:
                rgba(96,165,250,.65);

            box-shadow:
                0 10px 28px
                rgba(37,99,235,.30);

            transform:
                translateY(-1px);
        }


        .sb-three-dot-btn:active {

            transform:
                scale(.95);
        }


        .sb-three-dot-btn i {

            font-size: 18px;
        }


        /* ==========================================================
           3 DOT POPUP
        ========================================================== */

        .sb-menu-popup {

            position: fixed;

            top: 73px;

            right: 18px;

            z-index: 1000000;

            width: 290px;

            max-width:
                calc(100vw - 25px);

            padding: 10px;

            border:
                1px solid
                rgba(59,130,246,.22);

            border-radius: 20px;

            background:
                rgba(5,13,27,.97);

            box-shadow:
                0 25px 80px
                rgba(0,0,0,.48);

            backdrop-filter:
                blur(25px);

            opacity: 0;

            visibility: hidden;

            pointer-events: none;

            transform:
                translateY(-10px)
                scale(.96);

            transform-origin:
                top right;

            transition:
                opacity .2s ease,
                visibility .2s ease,
                transform .2s ease;
        }


        .sb-menu-popup.open {

            opacity: 1;

            visibility: visible;

            pointer-events: auto;

            transform:
                translateY(0)
                scale(1);
        }


        /* ==========================================================
           POPUP HEADER
        ========================================================== */

        .sb-menu-header {

            padding:
                11px 10px 13px;

            border-bottom:
                1px solid
                rgba(148,163,184,.20);

            margin-bottom: 5px;
        }


        .sb-menu-title {

            color: #ffffff;

            font-size: 13px;

            font-weight: 950;
        }


        .sb-menu-subtitle {

            margin-top: 4px;

            color: #94a3b8;

            font-size: 9px;
        }


        /* ==========================================================
           POPUP ITEM
        ========================================================== */

        .sb-menu-item {

            width: 100%;

            min-height: 43px;

            display: flex;

            align-items: center;

            gap: 11px;

            padding:
                8px 10px;

            border:
                1px solid
                transparent;

            border-radius: 12px;

            color: #dbeafe;

            background: transparent;

            text-decoration: none;

            cursor: pointer;

            font-size: 11px;

            font-weight: 850;

            transition:
                background .18s ease,
                color .18s ease,
                border-color .18s ease,
                transform .18s ease;
        }


        .sb-menu-item:hover {

            color: #ffffff;

            background:
                rgba(37,99,235,.14);

            border-color:
                rgba(59,130,246,.25);

            transform:
                translateX(2px);
        }


        .sb-menu-item-icon {

            width: 29px;

            height: 29px;

            flex-shrink: 0;

            display: grid;

            place-items: center;

            border-radius: 9px;

            color: #60a5fa;

            background:
                rgba(37,99,235,.10);

            font-size: 11px;
        }


        .sb-menu-item:hover
        .sb-menu-item-icon {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #4f46e5
                );
        }


        .sb-menu-item-text {

            flex: 1;

            text-align: left;
        }


        /* ==========================================================
           POPUP SEPARATOR
        ========================================================== */

        .sb-menu-separator {

            height: 1px;

            margin:
                7px 5px;

            background:
                rgba(148,163,184,.18);
        }


        /* ==========================================================
           THEME AREA
        ========================================================== */

        .sb-theme-label {

            display: flex;

            align-items: center;

            gap: 8px;

            padding:
                4px 10px 7px;

            color: #94a3b8;

            font-size: 9px;

            font-weight: 900;

            text-transform: uppercase;

            letter-spacing: .7px;
        }


        .sb-theme-buttons {

            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 7px;

            padding:
                0 0 3px;
        }


        .sb-theme-btn {

            height: 39px;

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 7px;

            border:
                1px solid
                rgba(59,130,246,.24);

            border-radius: 11px;

            color: #cbd5e1;

            background:
                rgba(7,22,42,.75);

            cursor: pointer;

            font-size: 10px;

            font-weight: 900;

            transition:
                all .2s ease;
        }


        .sb-theme-btn:hover {

            color: #ffffff;

            border-color:
                rgba(59,130,246,.55);

            background:
                rgba(37,99,235,.16);
        }


        .sb-theme-btn.active {

            color: #ffffff;

            border-color:
                rgba(96,165,250,.55);

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #6366f1
                );

            box-shadow:
                0 7px 20px
                rgba(37,99,235,.24);
        }


        /* ==========================================================
           AI / SMART AI POPUP
        ========================================================== */

        .sb-menu-item.ai-menu-item:hover {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    rgba(37,99,235,.28),
                    rgba(79,70,229,.22)
                );

            border-color:
                rgba(59,130,246,.48);
        }


        .sb-menu-item.smart-ai-menu-item:hover {

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    rgba(37,99,235,.28),
                    rgba(79,70,229,.22)
                );

            border-color:
                rgba(59,130,246,.48);
        }


        /* ==========================================================
           LOGOUT
        ========================================================== */

        .sb-logout {

            color: #fb7185;
        }


        .sb-logout
        .sb-menu-item-icon {

            color: #fb7185;

            background:
                rgba(220,38,38,.08);
        }


        .sb-logout:hover {

            color: #ffffff;

            background:
                rgba(220,38,38,.13);

            border-color:
                rgba(248,113,113,.22);
        }


        /* ==========================================================
           PAGE
        ========================================================== */

        .order-page {

            min-height: 100vh;

            padding:
                35px 15px 100px;

            background: transparent;
        }


        .order-container {

            max-width: 1180px;

            margin: auto;
        }


        /* ==========================================================
           TOP PAGE BAR
        ========================================================== */

        .order-topbar {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 15px;

            margin-bottom: 25px;
        }


        .back-btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            padding: 10px 16px;

            border:
                1px solid
                var(--order-border);

            border-radius: 12px;

            color: var(--order-text);

            background: var(--order-card);

            text-decoration: none;

            font-size: 13px;

            font-weight: 800;

            box-shadow:
                0 10px 30px
                rgba(15,23,42,.07);

            transition: all .22s ease;
        }


        .back-btn:hover {

            color: var(--order-primary);

            background:
                var(--order-primary-soft);

            border-color:
                var(--order-primary);

            transform:
                translateY(-2px);
        }


        .secure-pill {

            display: inline-flex;

            align-items: center;

            gap: 7px;

            padding: 9px 14px;

            border-radius: 999px;

            color: var(--order-success);

            background:
                rgba(34,197,94,.08);

            border:
                1px solid
                rgba(34,197,94,.18);

            font-size: 11px;

            font-weight: 850;
        }


        /* ==========================================================
           ORDER HEADER
        ========================================================== */

        .order-header {

            position: relative;

            overflow: hidden;

            padding: 30px;

            margin-bottom: 25px;

            border:
                1px solid
                var(--order-border);

            border-radius: 25px;

            background:
                var(--order-card);

            box-shadow:
                var(--order-header-shadow);

            backdrop-filter:
                blur(25px);

            transition:
                all .3s ease;
        }


        .order-header::before {

            content: "";

            position: absolute;

            top: 0;
            left: 0;
            right: 0;

            height: 3px;

            background:
                linear-gradient(
                    90deg,
                    #2563eb,
                    #3b82f6,
                    #6366f1
                );
        }


        .order-label {

            color: var(--order-primary);

            font-size: 11px;

            font-weight: 850;

            text-transform: uppercase;

            letter-spacing: 1.4px;
        }


        .order-title {

            margin:
                6px 0 5px;

            color:
                var(--order-heading);

            font-size: 31px;

            font-weight: 950;

            letter-spacing: -.8px;
        }


        .order-date {

            color:
                var(--order-muted);

            font-size: 13px;
        }


        .order-status {

            display: inline-flex;

            align-items: center;

            gap: 8px;

            margin-top: 15px;

            padding: 9px 15px;

            border-radius: 999px;

            color: var(--order-primary);

            background:
                var(--order-primary-soft);

            border:
                1px solid
                var(--order-border-strong);

            font-size: 12px;

            font-weight: 850;
        }


        .status-dot {

            width: 7px;

            height: 7px;

            border-radius: 50%;

            background: currentColor;

            box-shadow:
                0 0 0 4px
                rgba(59,130,246,.12);
        }


        /* ==========================================================
           PREMIUM CARD
        ========================================================== */

        .premium-card {

            overflow: hidden;

            border:
                1px solid
                var(--order-border);

            border-radius: 24px;

            background:
                var(--order-card);

            box-shadow:
                var(--order-shadow);

            backdrop-filter:
                blur(22px);

            transition:
                border-color .25s ease,
                box-shadow .25s ease,
                transform .25s ease;
        }


        .premium-card:hover {

            border-color:
                var(--order-border-strong);

            box-shadow:
                var(--order-header-shadow);
        }


        .card-header-premium {

            padding:
                20px 22px;

            border-bottom:
                1px solid
                var(--order-border);

            background:
                var(--order-surface);
        }


        .card-title {

            display: flex;

            align-items: center;

            gap: 10px;

            margin: 0;

            color:
                var(--order-heading);

            font-size: 16px;

            font-weight: 900;
        }


        .card-icon {

            width: 36px;

            height: 36px;

            display: grid;

            place-items: center;

            border-radius: 11px;

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #3b82f6
                );

            box-shadow:
                0 9px 25px
                rgba(37,99,235,.28);

            font-size: 14px;
        }


        .card-body-premium {

            padding: 22px;
        }


        /* ==========================================================
           PRODUCT
        ========================================================== */

        .product-row {

            display: flex;

            align-items: center;

            gap: 15px;

            padding: 14px;

            margin-bottom: 12px;

            border:
                1px solid
                var(--order-border);

            border-radius: 17px;

            background:
                var(--order-surface);

            transition: all .22s ease;
        }


        .product-row:last-child {

            margin-bottom: 0;
        }


        .product-row:hover {

            transform:
                translateX(3px);

            border-color:
                var(--order-border-strong);

            background:
                var(--order-primary-soft);
        }


        .product-image {

            width: 75px;

            height: 75px;

            flex-shrink: 0;

            object-fit: cover;

            border-radius: 14px;

            border:
                1px solid
                var(--order-border);

            background:
                var(--order-bg-secondary);
        }


        .product-info {

            flex: 1;
        }


        .product-name {

            margin-bottom: 5px;

            color:
                var(--order-heading);

            font-size: 14px;

            font-weight: 850;
        }


        .product-meta {

            color:
                var(--order-muted);

            font-size: 12px;

            line-height: 1.6;
        }


        .product-total {

            color:
                var(--order-primary);

            font-size: 14px;

            font-weight: 900;

            white-space: nowrap;
        }


        /* ==========================================================
           TOTAL
        ========================================================== */

        .total-box {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 15px;

            margin-top: 18px;

            padding: 18px;

            border:
                1px solid
                var(--order-border-strong);

            border-radius: 17px;

            background:
                linear-gradient(
                    135deg,
                    var(--order-primary-soft),
                    rgba(99,102,241,.06)
                );
        }


        .total-label {

            color:
                var(--order-primary);

            font-size: 11px;

            font-weight: 800;

            letter-spacing: .6px;
        }


        .total-amount {

            color:
                var(--order-heading);

            font-size: 23px;

            font-weight: 950;
        }


        /* ==========================================================
           DETAIL
        ========================================================== */

        .detail-row {

            display: flex;

            align-items: flex-start;

            gap: 12px;

            padding: 13px 0;

            border-bottom:
                1px solid
                var(--order-border);
        }


        .detail-row:last-child {

            border-bottom: 0;

            padding-bottom: 0;
        }


        .detail-icon {

            width: 35px;

            height: 35px;

            flex-shrink: 0;

            display: grid;

            place-items: center;

            border-radius: 10px;

            color:
                var(--order-primary);

            background:
                var(--order-primary-soft);

            border:
                1px solid
                var(--order-border);

            font-size: 13px;
        }


        .detail-label {

            color:
                var(--order-muted);

            font-size: 10px;

            font-weight: 800;

            text-transform: uppercase;

            letter-spacing: .5px;
        }


        .detail-value {

            margin-top: 3px;

            color:
                var(--order-heading);

            font-size: 13px;

            font-weight: 750;
        }


        /* ==========================================================
           DELIVERY PARTNER
        ========================================================== */

        .partner-box {

            display: flex;

            align-items: center;

            gap: 14px;

            padding: 15px;

            border:
                1px solid
                var(--order-border);

            border-radius: 17px;

            background:
                var(--order-surface);
        }


        .partner-image {

            width: 62px;

            height: 62px;

            object-fit: cover;

            border-radius: 15px;

            border:
                1px solid
                var(--order-border);

            background:
                var(--order-bg-secondary);
        }


        .partner-name {

            color:
                var(--order-heading);

            font-size: 14px;

            font-weight: 900;
        }


        .partner-meta {

            margin-top: 4px;

            color:
                var(--order-muted);

            font-size: 11px;
        }


        /* ==========================================================
           LOCATION
        ========================================================== */

        .tracking-location {

            display: flex;

            align-items: center;

            gap: 12px;

            margin-bottom: 25px;

            padding: 16px;

            border:
                1px solid
                var(--order-border-strong);

            border-radius: 17px;

            background:
                var(--order-primary-soft);
        }


        .location-icon {

            width: 43px;

            height: 43px;

            display: grid;

            place-items: center;

            flex-shrink: 0;

            border-radius: 13px;

            color: #ffffff;

            background:
                linear-gradient(
                    135deg,
                    #2563eb,
                    #1d4ed8
                );

            box-shadow:
                0 10px 28px
                rgba(37,99,235,.30);
        }


        .location-label {

            color:
                var(--order-muted);

            font-size: 10px;

            font-weight: 800;

            text-transform: uppercase;
        }


        .location-value {

            margin-top: 3px;

            color:
                var(--order-heading);

            font-size: 13px;

            font-weight: 850;
        }


        /* ==========================================================
           TIMELINE
        ========================================================== */

        .timeline {

            position: relative;

            margin: 0;

            padding:
                5px 0 5px 35px;

            list-style: none;
        }


        .timeline::before {

            content: "";

            position: absolute;

            left: 10px;

            top: 13px;

            bottom: 13px;

            width: 2px;

            background:
                var(--order-border);
        }


        .timeline-item {

            position: relative;

            min-height: 50px;

            padding:
                2px 0 22px;
        }


        .timeline-item:last-child {

            padding-bottom: 0;
        }


        .timeline-dot {

            position: absolute;

            left: -31px;

            top: 2px;

            width: 22px;

            height: 22px;

            display: grid;

            place-items: center;

            border-radius: 50%;

            color:
                var(--order-muted);

            background:
                var(--order-card);

            border:
                2px solid
                var(--order-border);

            font-size: 8px;

            z-index: 2;
        }


        .timeline-item.active
        .timeline-dot {

            color: #ffffff;

            background:
                var(--order-primary);

            border-color:
                var(--order-primary);

            box-shadow:
                0 0 0 5px
                rgba(59,130,246,.14);
        }


        .timeline-name {

            color:
                var(--order-muted);

            font-size: 12px;

            font-weight: 700;
        }


        .timeline-item.active
        .timeline-name {

            color:
                var(--order-heading);

            font-weight: 900;
        }


        /* ==========================================================
           CANCEL
        ========================================================== */

        .cancel-box {

            margin-top: 18px;

            padding: 18px;

            border:
                1px solid
                rgba(220,38,38,.18);

            border-radius: 17px;

            background:
                rgba(220,38,38,.05);
        }


        .cancel-title {

            color:
                var(--order-heading);

            font-size: 13px;

            font-weight: 850;
        }


        .cancel-description {

            margin-top: 4px;

            color:
                var(--order-muted);

            font-size: 11px;
        }


        .cancel-btn {

            margin-top: 12px;

            border:
                1px solid
                rgba(220,38,38,.28);

            border-radius: 11px;

            color:
                var(--order-danger);

            background: transparent;

            padding:
                9px 13px;

            font-size: 11px;

            font-weight: 850;

            transition: all .2s ease;
        }


        .cancel-btn:hover {

            color: #ffffff;

            background:
                var(--order-danger);

            border-color:
                var(--order-danger);

            transform:
                translateY(-1px);
        }


        .muted-text {

            color:
                var(--order-muted);

            font-size: 12px;
        }


        /* ==========================================================
           BOOTSTRAP DARK OVERRIDES
        ========================================================== */

        html[data-sb-theme="dark"] .text-dark,
        body[data-sb-theme="dark"] .text-dark {

            color:
                var(--order-heading) !important;
        }


        html[data-sb-theme="dark"] .bg-white,
        body[data-sb-theme="dark"] .bg-white {

            background:
                var(--order-card) !important;
        }


        html[data-sb-theme="dark"] .border,
        body[data-sb-theme="dark"] .border {

            border-color:
                var(--order-border) !important;
        }


        /* ==========================================================
           MOBILE TOPBAR
        ========================================================== */

        @media (max-width: 1100px) {

            .sb-brand {

                width: 170px;

                min-width: 170px;
            }


            .sb-nav-item {

                min-width: 80px;

                padding:
                    0 10px;
            }


            .sb-nav-item span {

                display: none;
            }


            .sb-smart-ai {

                min-width: 52px;

                width: 52px;

                padding: 0;
            }


            .sb-smart-ai-text {

                display: none;
            }


            .sb-user-box {

                min-width: 52px;

                width: 52px;

                padding: 0;

                justify-content: center;
            }


            .sb-user-text {

                display: none;
            }
        }


        @media (max-width: 767px) {

            body {

                padding-top: 68px;
            }


            .sb-topbar {

                height: 68px;

                padding:
                    8px 10px;

                gap: 7px;

                overflow: hidden;
            }


            .sb-brand {

                width: 48px;

                min-width: 48px;

                height: 48px;
            }


            .sb-brand-logo {

                width: 42px;

                height: 42px;

                border-radius: 12px;

                font-size: 18px;
            }


            .sb-brand-content {

                display: none;
            }


            .sb-topnav {

                gap: 5px;

                overflow: hidden;
            }


            .sb-nav-item {

                flex: 0 0 44px;

                width: 44px;

                min-width: 44px;

                height: 44px;

                padding: 0;

                border-radius: 12px;
            }


            .sb-nav-item span {

                display: none;
            }


            .sb-nav-item i {

                font-size: 13px;
            }


            .sb-smart-ai {

                flex: 0 0 44px;

                width: 44px;

                min-width: 44px;

                height: 44px;

                padding: 0;

                border-radius: 12px;
            }


            .sb-smart-ai-icon {

                width: 27px;

                height: 27px;
            }


            .sb-smart-ai-text,
            .sb-ai-online-dot {

                display: none;
            }


            .sb-user-box {

                flex: 0 0 44px;

                width: 44px;

                min-width: 44px;

                height: 44px;

                padding: 0;

                justify-content: center;

                border-radius: 12px;
            }


            .sb-user-text {

                display: none;
            }


            .sb-three-dot-btn {

                width: 44px;

                height: 44px;

                border-radius: 12px;
            }


            .sb-menu-popup {

                top: 62px;

                right: 10px;

                width: 285px;
            }


            .order-page {

                padding:
                    20px 10px 80px;
            }


            .order-topbar {

                align-items:
                    flex-start;

                flex-direction:
                    column;
            }


            .secure-pill {

                align-self:
                    flex-start;
            }


            .order-header {

                padding:
                    23px 18px;

                border-radius:
                    21px;
            }


            .order-title {

                font-size:
                    26px;
            }


            .card-header-premium,
            .card-body-premium {

                padding:
                    18px;
            }


            .product-row {

                align-items:
                    flex-start;
            }


            .product-image {

                width:
                    62px;

                height:
                    62px;
            }


            .product-total {

                font-size:
                    12px;
            }


            .total-box {

                align-items:
                    flex-start;

                flex-direction:
                    column;
            }


            .total-amount {

                font-size:
                    20px;
            }
        }

    </style>

</head>


@php

    /* ==========================================================
       CUSTOMER THEME
    ========================================================== */

    $customerTheme = auth()->check()
        ? (auth()->user()->dark_mode ?? 'light')
        : 'light';


    if (!in_array(
        $customerTheme,
        ['dark', 'light', 'system'],
        true
    )) {

        $customerTheme = 'light';

    }


    /* ==========================================================
       TRACKING STEPS
    ========================================================== */

    $steps = [

        'Order Placed',

        'Seller Confirmed',

        'Packed',

        'Picked By Delivery Partner',

        'Out For Delivery',

        'Near Customer',

        'Delivered'

    ];


    $current =
        $order->deliveryDetail?->status
        ?? $order->order_status
        ?? 'Order Placed';


    $currentIndex =
        array_search(
            $current,
            $steps,
            true
        );


    if ($currentIndex === false) {

        $currentIndex = 0;

    }


    /* ==========================================================
       ORDER TOTAL
    ========================================================== */

    $orderTotal = 0;


    foreach ($order->items ?? [] as $item) {

        $price =
            (float) ($item['price'] ?? 0);

        $quantity =
            (int) ($item['quantity'] ?? 1);

        $orderTotal +=
            $price * $quantity;

    }

@endphp


<body
    data-sb-theme="{{ $customerTheme }}"
    data-customer-theme="{{ $customerTheme }}"
>


<!-- ==============================================================
     SMART BASKET TOP TASKBAR
=============================================================== -->

<header
    class="sb-topbar"
    id="sbTopbar"
>


    <!-- BRAND -->

    <a
        href="{{ url('/') }}"
        class="sb-brand"
    >

        <span class="sb-brand-logo">

            <i class="fa-solid fa-basket-shopping"></i>

        </span>


        <span class="sb-brand-content">

            <span class="sb-brand-title">
                SMART BASKET
            </span>

            <span class="sb-brand-subtitle">
                CUSTOMER PANEL
            </span>

        </span>

    </a>


    <!-- MAIN NAV -->

    <nav class="sb-topnav">


        <!-- PRODUCTS -->

        <a
            href="{{ url('/products') }}"
            class="sb-nav-item"
        >

            <i class="fa-solid fa-store"></i>

            <span>
                Products
            </span>

        </a>


        <!-- ORDERS -->

        <a
            href="{{ route('orders.index') }}"
            class="sb-nav-item active"
        >

            <i class="fa-solid fa-box"></i>

            <span>
                Orders
            </span>

        </a>


        <!-- CART -->

        <a
            href="{{ url('/cart') }}"
            class="sb-nav-item"
        >

            <i class="fa-solid fa-cart-shopping"></i>

            <span>
                Cart
            </span>

        </a>


        <!-- WISHLIST -->

        <a
            href="{{ url('/wishlist') }}"
            class="sb-nav-item"
        >

            <i class="fa-regular fa-heart"></i>

            <span>
                Wishlist
            </span>

        </a>


        <!-- PROFILE -->

        <a
            href="{{ url('/profile') }}"
            class="sb-nav-item"
        >

            <i class="fa-regular fa-user"></i>

            <span>
                Profile
            </span>

        </a>


        <!-- SETTINGS -->

        <a
            href="{{ url('/settings') }}"
            class="sb-nav-item"
        >

            <i class="fa-solid fa-gear"></i>

            <span>
                Settings
            </span>

        </a>


        <!-- AI HUB -->

        <button
            type="button"
            class="sb-nav-item ai-hub"
            id="sbTopAiHub"
        >

            <i class="fa-solid fa-wand-magic-sparkles"></i>

            <span>
                AI HUB
            </span>

        </button>


    </nav>


    <!-- SMART AI -->

    <button
        type="button"
        class="sb-smart-ai"
        id="sbTopSmartAi"
    >

        <span class="sb-smart-ai-icon">

            <i class="fa-solid fa-robot"></i>

        </span>


        <span class="sb-smart-ai-text">
            Smart AI
        </span>


        <span class="sb-ai-online-dot"></span>

    </button>


    <!-- USER -->

    <div class="sb-user-box">

        <span class="sb-user-icon">

            <i class="fa-regular fa-user"></i>

        </span>


        <span class="sb-user-text">

            <div class="sb-user-hi">
                Hi,
            </div>

            <div class="sb-user-name">

                {{ auth()->user()->name ?? 'CUSTOMER' }}

            </div>

        </span>

    </div>


    <!-- ==========================================================
         3 DOT BUTTON
    =========================================================== -->

    <button
        type="button"
        class="sb-three-dot-btn"
        id="sbThreeDotButton"
        aria-label="Open menu"
        aria-expanded="false"
    >

        <i class="fa-solid fa-ellipsis-vertical"></i>

    </button>


</header>


<!-- ==============================================================
     3 DOT POPUP MENU
=============================================================== -->

<div
    class="sb-menu-popup"
    id="sbMenuPopup"
>


    <!-- HEADER -->

    <div class="sb-menu-header">

        <div class="sb-menu-title">

            SMART BASKET

        </div>


        <div class="sb-menu-subtitle">

            More options

        </div>

    </div>


    <!-- PRODUCTS HOME -->

    <a
        href="{{ url('/products') }}"
        class="sb-menu-item"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-solid fa-house"></i>

        </span>


        <span class="sb-menu-item-text">

            Products Home

        </span>

    </a>


    <!-- MY ORDERS -->

    <a
        href="{{ route('orders.index') }}"
        class="sb-menu-item"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-solid fa-box"></i>

        </span>


        <span class="sb-menu-item-text">

            My Orders

        </span>

    </a>


    <!-- CART -->

    <a
        href="{{ url('/cart') }}"
        class="sb-menu-item"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-solid fa-cart-shopping"></i>

        </span>


        <span class="sb-menu-item-text">

            Cart

        </span>

    </a>


    <!-- WISHLIST -->

    <a
        href="{{ url('/wishlist') }}"
        class="sb-menu-item"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-regular fa-heart"></i>

        </span>


        <span class="sb-menu-item-text">

            Wishlist

        </span>

    </a>


    <!-- PROFILE -->

    <a
        href="{{ url('/profile') }}"
        class="sb-menu-item"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-regular fa-user"></i>

        </span>


        <span class="sb-menu-item-text">

            Profile

        </span>

    </a>


    <!-- SETTINGS -->

    <a
        href="{{ url('/settings') }}"
        class="sb-menu-item"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-solid fa-gear"></i>

        </span>


        <span class="sb-menu-item-text">

            Settings

        </span>

    </a>


    <div class="sb-menu-separator"></div>


    <!-- THEME -->

    <div class="sb-theme-label">

        <i class="fa-solid fa-palette"></i>

        THEME

    </div>


    <div class="sb-theme-buttons">


        <button
            type="button"
            class="sb-theme-btn"
            id="sbLightTheme"
        >

            <i class="fa-solid fa-sun"></i>

            Light

        </button>


        <button
            type="button"
            class="sb-theme-btn"
            id="sbDarkTheme"
        >

            <i class="fa-solid fa-moon"></i>

            Dark

        </button>


    </div>


    <div class="sb-menu-separator"></div>


    <!-- AI HUB -->

    <button
        type="button"
        class="sb-menu-item ai-menu-item"
        id="sbMenuAiHub"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-solid fa-wand-magic-sparkles"></i>

        </span>


        <span class="sb-menu-item-text">

            Open AI HUB

        </span>

    </button>


    <!-- SMART AI -->

    <button
        type="button"
        class="sb-menu-item smart-ai-menu-item"
        id="sbMenuSmartAi"
    >

        <span class="sb-menu-item-icon">

            <i class="fa-solid fa-robot"></i>

        </span>


        <span class="sb-menu-item-text">

            Open Smart AI

        </span>

    </button>


    <div class="sb-menu-separator"></div>


    <!-- LOGOUT -->

    @auth

        <form
            method="POST"
            action="{{ route('logout') }}"
            style="margin:0;"
        >

            @csrf

            <button
                type="submit"
                class="sb-menu-item sb-logout"
            >

                <span class="sb-menu-item-icon">

                    <i class="fa-solid fa-right-from-bracket"></i>

                </span>


                <span class="sb-menu-item-text">

                    Logout

                </span>

            </button>

        </form>

    @endauth


</div>


<!-- ==============================================================
     ORDER PAGE
=============================================================== -->

<main class="order-page">

    <div class="order-container">


        <!-- TOP PAGE BAR -->

        <div class="order-topbar">


            <a
                href="{{ route('orders.index') }}"
                class="back-btn"
            >

                <i class="fa-solid fa-arrow-left"></i>

                My Orders

            </a>


            <div class="secure-pill">

                <i class="fa-solid fa-shield-halved"></i>

                Secure Order

            </div>

        </div>


        <!-- ORDER HEADER -->

        <section class="order-header">

            <div class="order-label">
                SMART BASKET ORDER
            </div>


            <h1 class="order-title">

                Order #{{ $order->id }}

            </h1>


            <div class="order-date">

                <i class="fa-regular fa-calendar"></i>

                Order tracking & details

            </div>


            <div class="order-status">

                <span class="status-dot"></span>

                {{ $current }}

            </div>

        </section>


        <!-- MAIN GRID -->

        <div class="row g-4">


            <!-- ==================================================
                 LEFT
            =================================================== -->

            <div class="col-lg-7">


                <!-- ORDER ITEMS -->

                <section class="premium-card">

                    <div class="card-header-premium">

                        <h2 class="card-title">

                            <span class="card-icon">

                                <i class="fa-solid fa-box"></i>

                            </span>

                            Order Items

                        </h2>

                    </div>


                    <div class="card-body-premium">


                        @forelse($order->items ?? [] as $item)

                            @php

                                $product =
                                    $products[
                                        $item['product_id'] ?? null
                                    ]
                                    ?? null;

                                $quantity =
                                    (int)
                                    ($item['quantity'] ?? 1);

                                $price =
                                    (float)
                                    ($item['price'] ?? 0);

                                $lineTotal =
                                    $price * $quantity;

                            @endphp


                            <div class="product-row">


                                <img
                                    src="{{
                                        $product && $product->image
                                            ? asset(
                                                'products/' .
                                                $product->image
                                            )
                                            : 'https://placehold.co/160x160/0B1426/FFFFFF?text=Product'
                                    }}"
                                    alt="{{
                                        $item['name']
                                        ?? $product?->name
                                        ?? 'Product'
                                    }}"
                                    class="product-image"
                                >


                                <div class="product-info">

                                    <div class="product-name">

                                        {{
                                            $item['name']
                                            ?? $product?->name
                                            ?? 'Product'
                                        }}

                                    </div>


                                    <div class="product-meta">

                                        ₹{{ number_format(
                                            $price,
                                            2
                                        ) }}

                                        ×

                                        {{ $quantity }}

                                        quantity

                                    </div>

                                </div>


                                <div class="product-total">

                                    ₹{{ number_format(
                                        $lineTotal,
                                        2
                                    ) }}

                                </div>


                            </div>

                        @empty

                            <div class="muted-text">

                                No products found for this order.

                            </div>

                        @endforelse


                        <div class="total-box">

                            <div>

                                <div class="total-label">
                                    ORDER TOTAL
                                </div>

                                <div class="muted-text">
                                    Final payable amount
                                </div>

                            </div>


                            <div class="total-amount">

                                ₹{{ number_format(
                                    $orderTotal,
                                    2
                                ) }}

                            </div>

                        </div>

                    </div>

                </section>


                <!-- TRACKING -->

                <section
                    class="premium-card mt-4"
                >

                    <div class="card-header-premium">

                        <h2 class="card-title">

                            <span class="card-icon">

                                <i class="fa-solid fa-location-dot"></i>

                            </span>

                            Track Your Order

                        </h2>

                    </div>


                    <div class="card-body-premium">


                        <div class="tracking-location">

                            <div class="location-icon">

                                <i class="fa-solid fa-location-dot"></i>

                            </div>


                            <div>

                                <div class="location-label">

                                    CURRENT LOCATION

                                </div>


                                <div class="location-value">

                                    {{
                                        $order
                                            ->deliveryDetail
                                            ?->current_location
                                        ?? 'Seller Warehouse'
                                    }}

                                </div>

                            </div>

                        </div>


                        <ol class="timeline">

                            @foreach($steps as $index => $step)

                                <li
                                    class="
                                        timeline-item
                                        {{
                                            $index <= $currentIndex
                                                ? 'active'
                                                : ''
                                        }}
                                    "
                                >

                                    <span class="timeline-dot">

                                        @if($index <= $currentIndex)

                                            <i
                                                class="fa-solid fa-check"
                                            ></i>

                                        @else

                                            <i
                                                class="fa-solid fa-circle"
                                            ></i>

                                        @endif

                                    </span>


                                    <div class="timeline-name">

                                        {{ $step }}

                                    </div>

                                </li>

                            @endforeach

                        </ol>

                    </div>

                </section>


            </div>


            <!-- ==================================================
                 RIGHT
            =================================================== -->

            <div class="col-lg-5">


                <!-- DELIVERY PARTNER -->

                <section class="premium-card">

                    <div class="card-header-premium">

                        <h2 class="card-title">

                            <span class="card-icon">

                                <i class="fa-solid fa-truck-fast"></i>

                            </span>

                            Delivery Partner

                        </h2>

                    </div>


                    <div class="card-body-premium">


                        @if(
                            $order->deliveryDetail?->deliveryPartner
                        )

                            @php

                                $partner =
                                    $order
                                        ->deliveryDetail
                                        ->deliveryPartner;

                            @endphp


                            <div class="partner-box">


                                <img
                                    src="{{
                                        $partner->image
                                            ? asset(
                                                'delivery-partners/' .
                                                $partner->image
                                            )
                                            : 'https://placehold.co/120x120/0B1426/FFFFFF?text=DP'
                                    }}"
                                    alt="{{ $partner->name }}"
                                    class="partner-image"
                                >


                                <div>

                                    <div class="partner-name">

                                        {{ $partner->name }}

                                    </div>


                                    @if($partner->phone)

                                        <div class="partner-meta">

                                            <i
                                                class="fa-solid fa-phone"
                                            ></i>

                                            {{ $partner->phone }}

                                        </div>

                                    @endif


                                    @if($partner->vehicle_number)

                                        <div class="partner-meta">

                                            <i
                                                class="fa-solid fa-motorcycle"
                                            ></i>

                                            {{ $partner->vehicle_number }}

                                        </div>

                                    @endif

                                </div>

                            </div>


                            <div class="detail-row mt-3">

                                <div class="detail-icon">

                                    <i
                                        class="fa-solid fa-location-crosshairs"
                                    ></i>

                                </div>


                                <div>

                                    <div class="detail-label">
                                        Current Location
                                    </div>


                                    <div class="detail-value">

                                        {{
                                            $order
                                                ->deliveryDetail
                                                ->current_location
                                            ?? $partner->current_location
                                            ?? 'Updating soon'
                                        }}

                                    </div>

                                </div>

                            </div>


                        @else

                            <div class="tracking-location">

                                <div class="location-icon">

                                    <i
                                        class="fa-solid fa-truck"
                                    ></i>

                                </div>


                                <div>

                                    <div class="location-label">

                                        DELIVERY PARTNER

                                    </div>


                                    <div class="location-value">

                                        Will be assigned soon

                                    </div>

                                </div>

                            </div>


                            <div class="muted-text">

                                A delivery partner will appear here
                                after seller assignment.

                            </div>

                        @endif

                    </div>

                </section>


                <!-- ORDER INFORMATION -->

                <section
                    class="premium-card mt-4"
                >

                    <div class="card-header-premium">

                        <h2 class="card-title">

                            <span class="card-icon">

                                <i class="fa-solid fa-receipt"></i>

                            </span>

                            Order Information

                        </h2>

                    </div>


                    <div class="card-body-premium">


                        <div class="detail-row">

                            <div class="detail-icon">

                                <i
                                    class="fa-solid fa-hashtag"
                                ></i>

                            </div>


                            <div>

                                <div class="detail-label">
                                    Order ID
                                </div>


                                <div class="detail-value">

                                    #{{ $order->id }}

                                </div>

                            </div>

                        </div>


                        <div class="detail-row">

                            <div class="detail-icon">

                                <i
                                    class="fa-solid fa-credit-card"
                                ></i>

                            </div>


                            <div>

                                <div class="detail-label">
                                    Payment
                                </div>


                                <div class="detail-value">

                                    {{
                                        $order->payment_method
                                        ?? 'Payment information available in order record'
                                    }}

                                </div>

                            </div>

                        </div>


                        <div class="detail-row">

                            <div class="detail-icon">

                                <i
                                    class="fa-solid fa-box-open"
                                ></i>

                            </div>


                            <div>

                                <div class="detail-label">
                                    Order Status
                                </div>


                                <div class="detail-value">

                                    {{
                                        $order->order_status
                                        ?? $current
                                    }}

                                </div>

                            </div>

                        </div>


                    </div>

                </section>


                <!-- CANCEL ORDER -->

                @if($order->isCancellable())

                    <section class="cancel-box">

                        <div class="cancel-title">

                            <i
                                class="fa-solid fa-circle-exclamation"
                            ></i>

                            Need to cancel this order?

                        </div>


                        <div class="cancel-description">

                            You can cancel this order while it is
                            still eligible for cancellation.

                        </div>


                        <form
                            action="{{
                                route(
                                    'orders.cancel',
                                    $order
                                )
                            }}"
                            method="POST"
                        >

                            @csrf

                            <button
                                type="submit"
                                class="cancel-btn"
                                onclick="
                                    return confirm(
                                        'Are you sure you want to cancel this order?'
                                    );
                                "
                            >

                                <i
                                    class="fa-solid fa-xmark"
                                ></i>

                                Cancel Order

                            </button>

                        </form>

                    </section>

                @endif


            </div>

        </div>

    </div>

</main>


<!-- ==============================================================
     SMART BASKET TASKBAR JAVASCRIPT
=============================================================== -->

<script>

(function () {

    'use strict';


    /* ==========================================================
       ELEMENTS
    ========================================================== */

    const body =
        document.body;


    const topbar =
        document.getElementById(
            'sbTopbar'
        );


    const threeDotButton =
        document.getElementById(
            'sbThreeDotButton'
        );


    const menuPopup =
        document.getElementById(
            'sbMenuPopup'
        );


    const lightButton =
        document.getElementById(
            'sbLightTheme'
        );


    const darkButton =
        document.getElementById(
            'sbDarkTheme'
        );


    const topAiHub =
        document.getElementById(
            'sbTopAiHub'
        );


    const menuAiHub =
        document.getElementById(
            'sbMenuAiHub'
        );


    const topSmartAi =
        document.getElementById(
            'sbTopSmartAi'
        );


    const menuSmartAi =
        document.getElementById(
            'sbMenuSmartAi'
        );


    /* ==========================================================
       POPUP OPEN / CLOSE
    ========================================================== */

    function openMenu() {

        if (!menuPopup) {

            return;

        }


        menuPopup.classList.add(
            'open'
        );


        if (threeDotButton) {

            threeDotButton.setAttribute(
                'aria-expanded',
                'true'
            );

        }

    }


    function closeMenu() {

        if (!menuPopup) {

            return;

        }


        menuPopup.classList.remove(
            'open'
        );


        if (threeDotButton) {

            threeDotButton.setAttribute(
                'aria-expanded',
                'false'
            );

        }

    }


    function toggleMenu() {

        if (!menuPopup) {

            return;

        }


        if (
            menuPopup.classList.contains(
                'open'
            )
        ) {

            closeMenu();

        } else {

            openMenu();

        }

    }


    /* ==========================================================
       3 DOT CLICK
    ========================================================== */

    if (threeDotButton) {

        threeDotButton.addEventListener(
            'click',
            function (event) {

                event.preventDefault();

                event.stopPropagation();

                toggleMenu();

            }
        );

    }


    /* ==========================================================
       OUTSIDE CLICK
    ========================================================== */

    document.addEventListener(
        'click',
        function (event) {

            if (!menuPopup) {

                return;

            }


            const clickedInsideMenu =
                menuPopup.contains(
                    event.target
                );


            const clickedButton =
                threeDotButton &&
                threeDotButton.contains(
                    event.target
                );


            if (
                !clickedInsideMenu &&
                !clickedButton
            ) {

                closeMenu();

            }

        }
    );


    /* ==========================================================
       ESC CLOSE
    ========================================================== */

    document.addEventListener(
        'keydown',
        function (event) {

            if (
                event.key === 'Escape'
            ) {

                closeMenu();

            }

        }
    );


    /* ==========================================================
       THEME
    ========================================================== */

    const customerTheme =
        body.dataset.customerTheme ||
        'light';


    function getSystemTheme() {

        return window.matchMedia(
            '(prefers-color-scheme: dark)'
        ).matches
            ? 'dark'
            : 'light';

    }


    function updateThemeButtons(
        theme
    ) {

        if (lightButton) {

            lightButton.classList.toggle(
                'active',
                theme === 'light'
            );

        }


        if (darkButton) {

            darkButton.classList.toggle(
                'active',
                theme === 'dark'
            );

        }

    }


    function applyTheme(
        theme
    ) {

        let finalTheme =
            theme;


        if (
            finalTheme !== 'dark' &&
            finalTheme !== 'light'
        ) {

            finalTheme =
                getSystemTheme();

        }


        document.documentElement.setAttribute(
            'data-sb-theme',
            finalTheme
        );


        document.documentElement.setAttribute(
            'data-theme',
            finalTheme
        );


        body.setAttribute(
            'data-sb-theme',
            finalTheme
        );


        body.setAttribute(
            'data-theme',
            finalTheme
        );


        document.documentElement.classList.remove(
            'dark',
            'light'
        );


        document.documentElement.classList.add(
            finalTheme
        );


        body.classList.remove(
            'dark',
            'light'
        );


        body.classList.add(
            finalTheme
        );


        updateThemeButtons(
            finalTheme
        );


        try {

            localStorage.setItem(
                'smartbasket-theme',
                finalTheme
            );

        } catch (error) {

            // Storage unavailable.

        }

    }


    /* ==========================================================
       INITIAL THEME
    ========================================================== */

    let savedTheme = null;


    try {

        savedTheme =
            localStorage.getItem(
                'smartbasket-theme'
            );

    } catch (error) {

        savedTheme = null;

    }


    if (
        savedTheme === 'dark' ||
        savedTheme === 'light'
    ) {

        applyTheme(
            savedTheme
        );

    } else {

        applyTheme(
            customerTheme
        );

    }


    /* ==========================================================
       LIGHT
    ========================================================== */

    if (lightButton) {

        lightButton.addEventListener(
            'click',
            function (event) {

                event.stopPropagation();

                applyTheme(
                    'light'
                );

            }
        );

    }


    /* ==========================================================
       DARK
    ========================================================== */

    if (darkButton) {

        darkButton.addEventListener(
            'click',
            function (event) {

                event.stopPropagation();

                applyTheme(
                    'dark'
                );

            }
        );

    }


    /* ==========================================================
       STORAGE SYNC
    ========================================================== */

    window.addEventListener(
        'storage',
        function (event) {

            if (
                event.key ===
                'smartbasket-theme'
            ) {

                if (
                    event.newValue === 'dark' ||
                    event.newValue === 'light'
                ) {

                    applyTheme(
                        event.newValue
                    );

                }

            }

        }
    );


    /* ==========================================================
       SAME TAB THEME SYNC
    ========================================================== */

    let lastTheme = null;


    try {

        lastTheme =
            localStorage.getItem(
                'smartbasket-theme'
            );

    } catch (error) {

        lastTheme = null;

    }


    setInterval(
        function () {

            try {

                const currentTheme =
                    localStorage.getItem(
                        'smartbasket-theme'
                    );


                if (
                    currentTheme &&
                    currentTheme !== lastTheme
                ) {

                    lastTheme =
                        currentTheme;

                    applyTheme(
                        currentTheme
                    );

                }

            } catch (error) {

                // Ignore.

            }

        },
        500
    );


    /* ==========================================================
       SYSTEM THEME
    ========================================================== */

    const media =
        window.matchMedia(
            '(prefers-color-scheme: dark)'
        );


    function systemThemeChanged() {

        if (
            body.dataset.customerTheme ===
            'system'
        ) {

            applyTheme(
                'system'
            );

        }

    }


    if (
        media.addEventListener
    ) {

        media.addEventListener(
            'change',
            systemThemeChanged
        );

    } else if (
        media.addListener
    ) {

        media.addListener(
            systemThemeChanged
        );

    }


    /* ==========================================================
       AI HUB FUNCTION
    ========================================================== */

    function openAIHub() {

        closeMenu();


        /*
        Existing AI Hub function ho
        to use karega.
        */

        if (
            typeof window.openAIHub ===
            'function'
        ) {

            window.openAIHub();

            return;

        }


        /*
        Common AI Hub selectors.
        */

        const aiHub =
            document.querySelector(
                '#aiHubSidebar, .ai-hub-sidebar, [data-ai-hub]'
            );


        if (aiHub) {

            aiHub.classList.toggle(
                'open'
            );

            return;

        }


        /*
        Common buttons ko try karega.
        */

        const aiButton =
            document.querySelector(
                '#aiHubButton, [data-open-ai-hub]'
            );


        if (aiButton) {

            aiButton.click();

            return;

        }


        console.log(
            'SMART BASKET AI HUB opened.'
        );

    }


    /* ==========================================================
       SMART AI FUNCTION
    ========================================================== */

    function openSmartAI() {

        closeMenu();


        /*
        Existing Smart AI function
        available ho to use karega.
        */

        if (
            typeof window.openSmartAI ===
            'function'
        ) {

            window.openSmartAI();

            return;

        }


        /*
        Common Smart AI selectors.
        */

        const smartAI =
            document.querySelector(
                '#smartAiSidebar, .smart-ai-sidebar, [data-smart-ai]'
            );


        if (smartAI) {

            smartAI.classList.toggle(
                'open'
            );

            return;

        }


        /*
        Common buttons.
        */

        const smartAIButton =
            document.querySelector(
                '#smartAIButton, [data-open-smart-ai]'
            );


        if (smartAIButton) {

            smartAIButton.click();

            return;

        }


        console.log(
            'SMART BASKET Smart AI opened.'
        );

    }


    /* ==========================================================
       TOP AI HUB
    ========================================================== */

    if (topAiHub) {

        topAiHub.addEventListener(
            'click',
            function () {

                openAIHub();

            }
        );

    }


    /* ==========================================================
       POPUP AI HUB
    ========================================================== */

    if (menuAiHub) {

        menuAiHub.addEventListener(
            'click',
            function () {

                openAIHub();

            }
        );

    }


    /* ==========================================================
       TOP SMART AI
    ========================================================== */

    if (topSmartAi) {

        topSmartAi.addEventListener(
            'click',
            function () {

                openSmartAI();

            }
        );

    }


    /* ==========================================================
       POPUP SMART AI
    ========================================================== */

    if (menuSmartAi) {

        menuSmartAi.addEventListener(
            'click',
            function () {

                openSmartAI();

            }
        );

    }


    /* ==========================================================
       PREVENT POPUP FORM CLICK FROM CLOSING
    ========================================================== */

    if (menuPopup) {

        menuPopup.addEventListener(
            'click',
            function (event) {

                event.stopPropagation();

            }
        );

    }


    /* ==========================================================
       WINDOW RESIZE
    ========================================================== */

    window.addEventListener(
        'resize',
        function () {

            if (
                window.innerWidth < 768 &&
                menuPopup &&
                menuPopup.classList.contains('open')
            ) {

                /*
                Popup automatically stays
                aligned with 3-dot button.
                */

            }

        }
    );


})();

</script>


</body>

</html>