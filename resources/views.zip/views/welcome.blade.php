
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, viewport-fit=cover"
    >

    <title>SMART BASKET</title>

    <!-- Poppins -->
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <style>

        /* =========================================================
           SMART BASKET — 8 SECOND PREMIUM RGB SPLASH
        ========================================================= */

        :root {
            --gold: #ffc400;
            --blue: #1769ff;
            --cyan: #00eaff;
            --purple: #9b4dff;
            --pink: #ff2bd6;
            --white: #ffffff;
            --black: #020308;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html,
        body {
            width: 100%;
            height: 100%;
        }

        body {
            min-height: 100vh;

            overflow: hidden;

            font-family: "Poppins", sans-serif;

            background: #020308;

            color: #fff;
        }


        /* =========================================================
           MAIN SPLASH
        ========================================================= */

        .sb-splash {

            position: relative;

            width: 100%;
            height: 100vh;
            height: 100dvh;

            min-height: 520px;

            display: flex;

            align-items: center;
            justify-content: center;

            overflow: hidden;

            isolation: isolate;

            background:
                radial-gradient(
                    circle at 50% 50%,
                    rgba(18, 55, 125, 0.34),
                    rgba(3, 7, 20, 0.82) 38%,
                    #020308 78%
                );

        }


        /* =========================================================
           ANIMATED RGB BACKGROUND AURA
        ========================================================= */

        .sb-rgb-aura {

            position: absolute;

            width: 85vw;
            height: 85vw;

            max-width: 1000px;
            max-height: 1000px;

            left: 50%;
            top: 50%;

            transform: translate(-50%, -50%);

            border-radius: 50%;

            background:
                conic-gradient(
                    from 0deg,
                    rgba(255, 196, 0, 0.10),
                    rgba(255, 0, 110, 0.10),
                    rgba(155, 77, 255, 0.12),
                    rgba(0, 234, 255, 0.10),
                    rgba(23, 105, 255, 0.12),
                    rgba(255, 196, 0, 0.10)
                );

            filter: blur(80px);

            opacity: 0.75;

            pointer-events: none;

            z-index: -8;

            animation:
                auraRotate 12s linear infinite,
                auraPulse 5s ease-in-out infinite;

        }


        /* =========================================================
           BLUE AMBIENT LIGHT
        ========================================================= */

        .sb-light-blue {

            position: absolute;

            width: 520px;
            height: 520px;

            top: -100px;
            left: -100px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(0, 102, 255, 0.30),
                    transparent 70%
                );

            filter: blur(70px);

            pointer-events: none;

            z-index: -7;

            animation:
                blueMove 7s ease-in-out infinite;

        }


        /* =========================================================
           GOLD AMBIENT LIGHT
        ========================================================= */

        .sb-light-gold {

            position: absolute;

            width: 500px;
            height: 500px;

            right: -120px;
            bottom: -100px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(255, 174, 0, 0.24),
                    transparent 70%
                );

            filter: blur(75px);

            pointer-events: none;

            z-index: -7;

            animation:
                goldMove 8s ease-in-out infinite;

        }


        /* =========================================================
           PURPLE AMBIENT LIGHT
        ========================================================= */

        .sb-light-purple {

            position: absolute;

            width: 420px;
            height: 420px;

            right: 10%;
            top: 5%;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(155, 77, 255, 0.18),
                    transparent 70%
                );

            filter: blur(85px);

            pointer-events: none;

            z-index: -7;

            animation:
                purpleMove 9s ease-in-out infinite;

        }


        /* =========================================================
           RGB BACKGROUND ORBIT
        ========================================================= */

        .sb-orbit {

            position: absolute;

            width: 80vw;
            height: 80vw;

            max-width: 900px;
            max-height: 900px;

            border-radius: 50%;

            border: 1px solid rgba(255,255,255,0.025);

            box-shadow:
                0 0 80px rgba(23,105,255,0.03),
                inset 0 0 80px rgba(255,196,0,0.02);

            pointer-events: none;

            z-index: -6;

            animation:
                orbitSpin 20s linear infinite;

        }

        .sb-orbit::before {

            content: "";

            position: absolute;

            width: 8px;
            height: 8px;

            left: 8%;
            top: 12%;

            border-radius: 50%;

            background: var(--cyan);

            box-shadow:
                0 0 12px var(--cyan),
                0 0 30px var(--cyan),
                0 0 55px rgba(0,234,255,0.4);

        }

        .sb-orbit::after {

            content: "";

            position: absolute;

            width: 7px;
            height: 7px;

            right: 10%;
            bottom: 15%;

            border-radius: 50%;

            background: var(--gold);

            box-shadow:
                0 0 12px var(--gold),
                0 0 30px var(--gold),
                0 0 55px rgba(255,196,0,0.4);

        }


        /* =========================================================
           PREMIUM GRID
        ========================================================= */

        .sb-grid {

            position: absolute;

            inset: 0;

            pointer-events: none;

            opacity: 0.12;

            background-image:
                linear-gradient(
                    rgba(255,255,255,0.028) 1px,
                    transparent 1px
                ),
                linear-gradient(
                    90deg,
                    rgba(255,255,255,0.028) 1px,
                    transparent 1px
                );

            background-size: 65px 65px;

            mask-image:
                radial-gradient(
                    circle at center,
                    black 0%,
                    transparent 70%
                );

            -webkit-mask-image:
                radial-gradient(
                    circle at center,
                    black 0%,
                    transparent 70%
                );

            z-index: -5;

            animation:
                gridMove 12s linear infinite;

        }


        /* =========================================================
           TOP / BOTTOM LINES
        ========================================================= */

        .sb-line {

            position: absolute;

            height: 1px;

            left: 7%;
            right: 7%;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    rgba(255,196,0,0.55),
                    rgba(255,255,255,0.20),
                    rgba(0,234,255,0.55),
                    rgba(155,77,255,0.35),
                    transparent
                );

            opacity: 0.50;

            pointer-events: none;

            z-index: -2;

            background-size: 300% 100%;

            animation:
                lineRGB 6s linear infinite;

        }

        .sb-line-top {
            top: 7%;
        }

        .sb-line-bottom {
            bottom: 7%;
        }


        /* =========================================================
           CORNER ACCENTS
        ========================================================= */

        .sb-corner {

            position: absolute;

            width: 85px;
            height: 85px;

            opacity: 0.40;

            pointer-events: none;

        }

        .sb-corner::before,
        .sb-corner::after {

            content: "";

            position: absolute;

            background:
                linear-gradient(
                    90deg,
                    var(--gold),
                    var(--pink),
                    var(--blue),
                    transparent
                );

            background-size: 300% 100%;

            animation:
                cornerRGB 4s linear infinite;

        }

        .sb-corner::before {

            width: 85px;
            height: 1px;

        }

        .sb-corner::after {

            width: 1px;
            height: 85px;

        }

        .sb-corner-tl {
            top: 5%;
            left: 5%;
        }

        .sb-corner-tr {

            top: 5%;
            right: 5%;

            transform: rotate(90deg);

        }

        .sb-corner-bl {

            bottom: 5%;
            left: 5%;

            transform: rotate(-90deg);

        }

        .sb-corner-br {

            bottom: 5%;
            right: 5%;

            transform: rotate(180deg);

        }


        /* =========================================================
           MAIN CONTENT
        ========================================================= */

        .sb-content {

            position: relative;

            z-index: 10;

            width: min(1100px, 94vw);

            display: flex;

            flex-direction: column;

            align-items: center;

            justify-content: center;

            animation:
                contentReveal 1.2s ease-out forwards;

        }


        /* =========================================================
           LOGO FRAME
        ========================================================= */

        .sb-logo-frame {

            position: relative;

            width: min(900px, 88vw);

            display: flex;

            align-items: center;
            justify-content: center;

            padding: 5px;

            border-radius: 26px;

            isolation: isolate;

            animation:
                logoReveal 1.7s cubic-bezier(.16,1,.3,1) forwards,
                logoFloat 6s ease-in-out 1.7s infinite;

        }


        /* =========================================================
           RGB ANIMATED BORDER — MAIN
        ========================================================= */

        .sb-logo-frame::before {

            content: "";

            position: absolute;

            inset: 0;

            border-radius: 26px;

            padding: 2px;

            background:
                conic-gradient(
                    from 0deg,
                    #ffc400,
                    #ff8a00,
                    #ff2bd6,
                    #9b4dff,
                    #1769ff,
                    #00eaff,
                    #00ff88,
                    #ffc400
                );

            background-size: 200% 200%;

            animation:
                rgbBorder 4s linear infinite;

            -webkit-mask:
                linear-gradient(#fff 0 0) content-box,
                linear-gradient(#fff 0 0);

            -webkit-mask-composite: xor;

            mask-composite: exclude;

            z-index: -1;

            filter:
                drop-shadow(0 0 5px rgba(255,196,0,0.75))
                drop-shadow(0 0 15px rgba(0,234,255,0.45))
                drop-shadow(0 0 28px rgba(255,43,214,0.30));

        }


        /* =========================================================
           SECONDARY BORDER GLOW
        ========================================================= */

        .sb-logo-frame::after {

            content: "";

            position: absolute;

            inset: -8px;

            border-radius: 32px;

            background:
                conic-gradient(
                    from 180deg,
                    rgba(255,196,0,0.20),
                    rgba(255,43,214,0.18),
                    rgba(23,105,255,0.20),
                    rgba(0,234,255,0.18),
                    rgba(255,196,0,0.20)
                );

            filter: blur(18px);

            opacity: 0.75;

            z-index: -2;

            animation:
                glowRotate 5s linear infinite;

        }


        /* =========================================================
           LOGO IMAGE
        ========================================================= */

        .sb-logo {

            position: relative;

            display: block;

            width: 100%;

            height: auto;

            max-height: 76vh;

            object-fit: contain;

            border-radius: 22px;

            user-select: none;

            pointer-events: none;

            -webkit-user-drag: none;

            background:
                rgba(2,3,8,0.20);

            filter:
                drop-shadow(
                    0 25px 55px rgba(0,0,0,0.70)
                )
                drop-shadow(
                    0 0 25px rgba(255,196,0,0.12)
                );

            animation:
                logoBrightness 2.5s ease-out forwards;

        }


        /* =========================================================
           LOGO INNER LIGHT
        ========================================================= */

        .sb-logo-frame .sb-inner-glow {

            position: absolute;

            inset: 10px;

            border-radius: 20px;

            pointer-events: none;

            background:
                radial-gradient(
                    ellipse at center,
                    transparent 55%,
                    rgba(255,196,0,0.045),
                    transparent 85%
                );

            z-index: 2;

        }


        /* =========================================================
           LOADING
        ========================================================= */

        .sb-loading {

            margin-top: clamp(14px, 2vh, 22px);

            display: flex;

            flex-direction: column;

            align-items: center;

            gap: 11px;

            opacity: 0;

            animation:
                loadingReveal 1s ease-out 1.2s forwards;

        }

        .sb-loading-text {

            font-size: 10px;

            font-weight: 600;

            letter-spacing: 4px;

            text-transform: uppercase;

            color: rgba(255,255,255,0.62);

            text-align: center;

            text-shadow:
                0 0 10px rgba(255,255,255,0.10);

        }


        /* =========================================================
           RGB LOADER
        ========================================================= */

        .sb-loader {

            position: relative;

            width: 180px;

            height: 3px;

            overflow: hidden;

            border-radius: 100px;

            background:
                rgba(255,255,255,0.08);

            box-shadow:
                0 0 12px rgba(23,105,255,0.10);

        }

        .sb-loader::before {

            content: "";

            position: absolute;

            top: 0;
            bottom: 0;

            left: -60%;

            width: 60%;

            border-radius: inherit;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    #ffc400,
                    #ff2bd6,
                    #9b4dff,
                    #1769ff,
                    #00eaff,
                    transparent
                );

            background-size: 200% 100%;

            animation:
                loaderMove 2s ease-in-out infinite,
                loaderRGB 3s linear infinite;

        }


        /* =========================================================
           ANIMATIONS
        ========================================================= */

        @keyframes contentReveal {

            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }

        }


        @keyframes logoReveal {

            0% {

                opacity: 0;

                transform:
                    scale(0.78)
                    translateY(25px);

            }

            55% {

                opacity: 1;

                transform:
                    scale(1.025)
                    translateY(0);

            }

            100% {

                opacity: 1;

                transform:
                    scale(1)
                    translateY(0);

            }

        }


        @keyframes logoFloat {

            0% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-5px);
            }

            100% {
                transform: translateY(0);
            }

        }


        /* RGB BORDER ROTATION */

        @keyframes rgbBorder {

            0% {
                background-position: 0% 50%;
                transform: rotate(0deg);
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
                transform: rotate(0deg);
            }

        }


        @keyframes glowRotate {

            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }

        }


        @keyframes logoBrightness {

            from {

                filter:
                    brightness(0.72)
                    saturate(0.75)
                    drop-shadow(
                        0 20px 45px rgba(0,0,0,0.65)
                    );

            }

            to {

                filter:
                    brightness(1)
                    saturate(1)
                    drop-shadow(
                        0 25px 55px rgba(0,0,0,0.70)
                    )
                    drop-shadow(
                        0 0 25px rgba(255,196,0,0.12)
                    );

            }

        }


        @keyframes loadingReveal {

            from {

                opacity: 0;

                transform:
                    translateY(8px);

            }

            to {

                opacity: 1;

                transform:
                    translateY(0);

            }

        }


        @keyframes loaderMove {

            0% {
                left: -60%;
            }

            50% {
                left: 100%;
            }

            100% {
                left: 100%;
            }

        }


        @keyframes loaderRGB {

            0% {
                filter: hue-rotate(0deg);
            }

            100% {
                filter: hue-rotate(360deg);
            }

        }


        @keyframes auraRotate {

            0% {
                transform:
                    translate(-50%, -50%)
                    rotate(0deg);
            }

            100% {
                transform:
                    translate(-50%, -50%)
                    rotate(360deg);
            }

        }


        @keyframes auraPulse {

            0%,
            100% {
                opacity: 0.55;
                transform:
                    translate(-50%, -50%)
                    scale(0.95);
            }

            50% {
                opacity: 0.85;
                transform:
                    translate(-50%, -50%)
                    scale(1.08);
            }

        }


        @keyframes blueMove {

            0%,
            100% {
                transform:
                    translate(0,0)
                    scale(1);
            }

            50% {
                transform:
                    translate(100px,80px)
                    scale(1.25);
            }

        }


        @keyframes goldMove {

            0%,
            100% {
                transform:
                    translate(0,0)
                    scale(1);
            }

            50% {
                transform:
                    translate(-100px,-80px)
                    scale(1.20);
            }

        }


        @keyframes purpleMove {

            0%,
            100% {
                transform:
                    translate(0,0)
                    scale(1);
            }

            50% {
                transform:
                    translate(-80px,100px)
                    scale(1.20);
            }

        }


        @keyframes orbitSpin {

            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }

        }


        @keyframes gridMove {

            from {
                background-position:
                    0 0,
                    0 0;
            }

            to {
                background-position:
                    65px 65px,
                    65px 65px;
            }

        }


        @keyframes lineRGB {

            0% {
                background-position: 0% 50%;
            }

            100% {
                background-position: 300% 50%;
            }

        }


        @keyframes cornerRGB {

            0% {
                background-position: 0% 50%;
            }

            100% {
                background-position: 300% 50%;
            }

        }


        /* =========================================================
           TABLET
        ========================================================= */

        @media (max-width: 900px) {

            .sb-logo-frame {
                width: 91vw;
            }

            .sb-line {
                left: 5%;
                right: 5%;
            }

            .sb-corner {
                opacity: 0.28;
            }

        }


        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 600px) {

            .sb-splash {
                min-height: 100svh;
            }

            .sb-logo-frame {

                width: 94vw;

                padding: 4px;

                border-radius: 18px;

            }

            .sb-logo {

                max-height: 62vh;

                border-radius: 15px;

            }

            .sb-logo-frame::before {
                border-radius: 18px;
            }

            .sb-logo-frame::after {
                border-radius: 23px;
            }

            .sb-loading {
                margin-top: 8px;
            }

            .sb-loading-text {

                font-size: 8px;

                letter-spacing: 3px;

            }

            .sb-loader {
                width: 135px;
            }

            .sb-line {

                left: 12%;
                right: 12%;

            }

            .sb-corner {

                width: 55px;
                height: 55px;

                opacity: 0.20;

            }

            .sb-corner::before {
                width: 55px;
            }

            .sb-corner::after {
                height: 55px;
            }

            .sb-light-blue,
            .sb-light-gold,
            .sb-light-purple {

                filter: blur(65px);

            }

        }


        /* =========================================================
           SHORT SCREEN
        ========================================================= */

        @media (max-height: 650px) {

            .sb-logo-frame {

                width: min(720px, 80vw);

            }

            .sb-logo {

                max-height: 66vh;

            }

            .sb-loading {

                margin-top: 5px;

            }

        }


        /* =========================================================
           REDUCED MOTION
        ========================================================= */

        @media (prefers-reduced-motion: reduce) {

            *,
            *::before,
            *::after {

                animation-duration: 0.01ms !important;

                animation-iteration-count: 1 !important;

            }

        }

    </style>
</head>


<body>

    <main class="sb-splash">


        <!-- =====================================================
             BACKGROUND EFFECTS
        ===================================================== -->

        <div class="sb-rgb-aura"></div>

        <div class="sb-light-blue"></div>

        <div class="sb-light-gold"></div>

        <div class="sb-light-purple"></div>

        <div class="sb-orbit"></div>

        <div class="sb-grid"></div>


        <!-- =====================================================
             DECORATIVE LINES
        ===================================================== -->

        <div class="sb-line sb-line-top"></div>

        <div class="sb-line sb-line-bottom"></div>


        <!-- =====================================================
             CORNERS
        ===================================================== -->

        <div class="sb-corner sb-corner-tl"></div>

        <div class="sb-corner sb-corner-tr"></div>

        <div class="sb-corner sb-corner-bl"></div>

        <div class="sb-corner sb-corner-br"></div>


        <!-- =====================================================
             MAIN CONTENT
        ===================================================== -->

        <section class="sb-content">


            <!-- =================================================
                 LOGO + RGB BORDER
            ================================================= -->

            <div class="sb-logo-frame">

                <img
                    src="{{ asset('images/smart-basket-logo.png') }}"
                    alt="SMART BASKET"
                    class="sb-logo"
                    draggable="false"
                >

                <div class="sb-inner-glow"></div>

            </div>


            <!-- =================================================
                 LOADING
            ================================================= -->

            <div class="sb-loading">

                <div class="sb-loading-text">
                    PREMIUM SHOPPING EXPERIENCE
                </div>

                <div class="sb-loader"></div>

            </div>


        </section>


    </main>


    <!-- =========================================================
         SMART BASKET — 8 SECOND REDIRECT
    ========================================================= -->

    <script>

        /*
         * Splash duration:
         *
         * 8000 milliseconds = 8 seconds
         */

        window.setTimeout(function () {

            window.location.href = "{{ route('login') }}";

        }, 8000);

    </script>


</body>
</html>
