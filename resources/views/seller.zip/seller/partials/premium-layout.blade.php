<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        @yield('title', 'Seller Partner Program')
    </title>

    <link
        rel="stylesheet"
        href="{{ asset('css/seller-premium.css') }}"
    >

    <script>
        (() => {
            const saved = localStorage.getItem('sb-theme');

            if (saved) {
                document.documentElement.dataset.theme = saved;
            } else if (
                window.matchMedia &&
                window.matchMedia('(prefers-color-scheme: dark)').matches
            ) {
                document.documentElement.dataset.theme = 'dark';
            }
        })();

        function toggleSellerTheme() {
            const current =
                document.documentElement.dataset.theme === 'dark'
                    ? 'light'
                    : 'dark';

            document.documentElement.dataset.theme = current;
            localStorage.setItem('sb-theme', current);
        }
    </script>
</head>

<body>

<div class="sb-shell">

    <div class="sb-container">

        <header class="sb-header">

            <div class="sb-brand">

                <div class="sb-logo">
                    SB
                </div>

                <div>
                    <div class="sb-brand-title">
                        SMART BASKET
                    </div>

                    <div class="sb-brand-subtitle">
                        Seller Partner Program
                    </div>
                </div>

            </div>

            <button
                type="button"
                class="sb-theme"
                onclick="toggleSellerTheme()"
            >
                ◐ Theme
            </button>

        </header>

        <div class="sb-progress">

            @for($i = 1; $i <= 6; $i++)

                <div
                    class="sb-progress-item
                    @if($step >= $i) active @endif"
                ></div>

            @endfor

        </div>

        @if(session('success'))
            <div class="sb-alert success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="sb-alert error">
                {{ session('error') }}
            </div>
        @endif

        @if($errors->any())
            <div class="sb-alert error">
                <strong>Please check the following:</strong>

                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <main>
            @yield('content')
        </main>

    </div>

</div>

</body>
</html>