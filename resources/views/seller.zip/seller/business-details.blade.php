@extends('seller.partials.premium-layout')

@section('title', 'Business Details')

@php
    $step = 2;
@endphp

@section('content')

<div class="sb-card">

    <div class="sb-step">
        STEP 2 OF 6
    </div>

    <h1 class="sb-title">
        Tell us about your business
    </h1>

    <p class="sb-description">
        Save your business information. You can return and edit it anytime.
    </p>

    <form
        method="POST"
        action="{{ route('seller.verification.business-details.update') }}"
    >

        @csrf
        @method('PUT')

        <div class="sb-grid">

            <div class="sb-field">

                <label class="sb-label">
                    Business Type *
                </label>

                <select
                    name="business_type"
                    class="sb-select"
                    required
                >

                    <option value="">
                        Select business type
                    </option>

                    @foreach([
                        'Individual Seller',
                        'Proprietorship',
                        'Partnership',
                        'Private Limited',
                        'LLP',
                        'Other'
                    ] as $type)

                        <option
                            value="{{ $type }}"
                            @selected(
                                old(
                                    'business_type',
                                    $seller->business_type
                                ) === $type
                            )
                        >
                            {{ $type }}
                        </option>

                    @endforeach

                </select>

            </div>

            <div class="sb-field">

                <label class="sb-label">
                    GST Number
                </label>

                <input
                    type="text"
                    name="gst_number"
                    class="sb-input"
                    value="{{ old('gst_number', $seller->gst_number) }}"
                    placeholder="Enter GST number"
                >

            </div>

            <div class="sb-field">

                <label class="sb-label">
                    PAN Number
                </label>

                <input
                    type="text"
                    name="pan_number"
                    class="sb-input"
                    value="{{ old('pan_number', $seller->pan_number) }}"
                    placeholder="Enter PAN"
                >

            </div>

            <div class="sb-field">

                <label class="sb-label">
                    Udyam Number
                </label>

                <input
                    type="text"
                    name="udyam_number"
                    class="sb-input"
                    value="{{ old('udyam_number', $seller->udyam_number) }}"
                    placeholder="Enter Udyam number"
                >

            </div>

        </div>

        <div class="sb-actions">

            <a
                href="{{ route('seller.verification.email') }}"
                class="sb-btn"
            >
                ← Back
            </a>

            <button
                type="submit"
                class="sb-btn sb-btn-primary"
            >
                Save & Continue →
            </button>

        </div>

    </form>

</div>

@endsection

{{-- ============================================================
     BUSINESS TYPE DARK THEME FIX
     Only dropdown theme is changed.
     Existing page/layout/design remains untouched.
     ============================================================ --}}

<style>
    /*
     * Dark theme:
     * Keep the existing .sb-select design,
     * only make the native dropdown readable.
     */

    .sb-select {
        color: #f8fafc !important;
        background-color: #111827 !important;
        color-scheme: dark;
    }

    .sb-select option {
        color: #f8fafc !important;
        background-color: #111827 !important;
    }

    .sb-select option:checked,
    .sb-select option:hover {
        color: #ffffff !important;
        background-color: #1f2937 !important;
    }

    /*
     * Placeholder option
     */
    .sb-select option[value=""] {
        color: #9ca3af !important;
        background-color: #111827 !important;
    }

    /*
     * When the page is using light theme,
     * don't force dark dropdown colors.
     */
    html.light .sb-select,
    body.light .sb-select {
        color: #111827 !important;
        background-color: #ffffff !important;
        color-scheme: light;
    }

    html.light .sb-select option,
    body.light .sb-select option {
        color: #111827 !important;
        background-color: #ffffff !important;
    }

    html.light .sb-select option[value=""],
    body.light .sb-select option[value=""] {
        color: #6b7280 !important;
    }
</style>