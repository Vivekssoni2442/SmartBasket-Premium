@extends('seller.partials.premium-layout')

@section('title', 'Seller Documents')

@php
    $step = 3;
@endphp

@section('content')

<div class="sb-card">

    <div class="sb-step">
        STEP 3 OF 6
    </div>

    <h1 class="sb-title">
        Verify your documents
    </h1>

    <p class="sb-description">
        Upload clear documents. You can replace them later if needed.
    </p>

    <form
        method="POST"
        action="{{ route('seller.verification.documents.upload') }}"
        enctype="multipart/form-data"
    >

        @csrf

        <div class="sb-grid">

            <div class="sb-field">

                <label class="sb-label">
                    Business Certificate *
                </label>

                <input
                    type="file"
                    name="business_certificate"
                    class="sb-input"
                    accept=".jpg,.jpeg,.png,.webp"
                    required
                >

                @if($seller->business_certificate_path)
                    <small>
                        ✓ Document already uploaded
                    </small>
                @endif

            </div>

            <div class="sb-field">

                <label class="sb-label">
                    Aadhaar Document *
                </label>

                <input
                    type="file"
                    name="aadhaar_document"
                    class="sb-input"
                    accept=".jpg,.jpeg,.png,.webp"
                    required
                >

                @if($seller->aadhaar_document_path)
                    <small>
                        ✓ Aadhaar already uploaded
                    </small>
                @endif

            </div>

            <div class="sb-field">

                <label class="sb-label">
                    Business Type *
                </label>

                <input
                    type="text"
                    name="business_type"
                    class="sb-input"
                    value="{{ old('business_type', $seller->business_type) }}"
                    required
                >

            </div>

            <div class="sb-field">

                <label class="sb-label">
                    PAN Number
                </label>

                <input
                    type="text"
                    name="pan_number"
                    class="sb-input"
                    value="{{ old('pan_number', $seller->pan_number) }}"
                >

            </div>

            <div class="sb-field full">

                <label class="sb-label">
                    Udyam Number
                </label>

                <input
                    type="text"
                    name="udyam_number"
                    class="sb-input"
                    value="{{ old('udyam_number', $seller->udyam_number) }}"
                >

            </div>

        </div>

        <div class="sb-actions">

            <a
                href="{{ route('seller.verification.business') }}"
                class="sb-btn"
            >
                ← Back
            </a>

            <button
                type="submit"
                class="sb-btn sb-btn-primary"
            >
                Save & Continue →
            </button>

        </div>

    </form>

</div>

@endsection