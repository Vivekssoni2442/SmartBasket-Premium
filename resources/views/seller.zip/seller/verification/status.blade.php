<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Seller Verification Status | SmartBasket Premium</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: Inter, Arial, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(99,102,241,.20), transparent 35%),
                radial-gradient(circle at bottom right, rgba(14,165,233,.15), transparent 35%),
                #070b14;
            color: #fff;
            padding: 30px 18px;
        }

        .container {
            width: min(900px, 100%);
            margin: auto;
        }

        .brand {
            text-align: center;
            margin-bottom: 30px;
        }

        .brand h1 {
            font-size: 30px;
            font-weight: 800;
            letter-spacing: .5px;
        }

        .brand span {
            color: #60a5fa;
        }

        .card {
            background: rgba(15, 23, 42, .88);
            border: 1px solid rgba(148,163,184,.18);
            border-radius: 24px;
            padding: 35px;
            box-shadow: 0 25px 80px rgba(0,0,0,.35);
            backdrop-filter: blur(18px);
        }

        .title {
            text-align: center;
            margin-bottom: 25px;
        }

        .title h2 {
            font-size: 28px;
            margin-bottom: 8px;
        }

        .title p {
            color: #94a3b8;
        }

        .seller-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin: 25px 0;
        }

        .info {
            background: rgba(30,41,59,.65);
            border: 1px solid rgba(148,163,184,.12);
            padding: 16px;
            border-radius: 14px;
        }

        .info small {
            display: block;
            color: #94a3b8;
            margin-bottom: 6px;
        }

        .info strong {
            color: #f8fafc;
            word-break: break-word;
        }

        .status {
            text-align: center;
            padding: 25px;
            border-radius: 18px;
            margin: 25px 0;
        }

        .status.pending {
            background: rgba(245,158,11,.10);
            border: 1px solid rgba(245,158,11,.35);
        }

        .status.approved {
            background: rgba(34,197,94,.10);
            border: 1px solid rgba(34,197,94,.35);
        }

        .status.rejected {
            background: rgba(239,68,68,.10);
            border: 1px solid rgba(239,68,68,.35);
        }

        .status.suspended {
            background: rgba(239,68,68,.10);
            border: 1px solid rgba(239,68,68,.35);
        }

        .status-icon {
            font-size: 45px;
            margin-bottom: 10px;
        }

        .status h3 {
            font-size: 22px;
            margin-bottom: 8px;
        }

        .status p {
            color: #cbd5e1;
            line-height: 1.6;
        }

        .steps {
            margin-top: 30px;
        }

        .steps h3 {
            margin-bottom: 18px;
        }

        .step {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 14px;
            background: rgba(30,41,59,.55);
        }

        .circle {
            width: 36px;
            height: 36px;
            min-width: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #334155;
            font-weight: 700;
        }

        .circle.done {
            background: #22c55e;
            color: #052e16;
        }

        .step-text strong {
            display: block;
            margin-bottom: 3px;
        }

        .step-text small {
            color: #94a3b8;
        }

        .actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 12px;
            margin-top: 30px;
        }

        .btn {
            display: inline-block;
            padding: 13px 22px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            border: 0;
            cursor: pointer;
        }

        .btn-primary {
            background: #3b82f6;
            color: white;
        }

        .btn-secondary {
            background: #1e293b;
            color: white;
            border: 1px solid #334155;
        }

        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        .alert.success {
            background: rgba(34,197,94,.12);
            border: 1px solid rgba(34,197,94,.3);
            color: #86efac;
        }

        .alert.error {
            background: rgba(239,68,68,.12);
            border: 1px solid rgba(239,68,68,.3);
            color: #fca5a5;
        }

        @media(max-width: 650px) {
            .card {
                padding: 22px;
            }

            .seller-info {
                grid-template-columns: 1fr;
            }

            .title h2 {
                font-size: 23px;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <div class="brand">
        <h1>SMART BASKET <span>PREMIUM</span></h1>
    </div>

    <div class="card">

        @if(session('success'))
            <div class="alert success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert error">
                {{ session('error') }}
            </div>
        @endif

        <div class="title">
            <h2>Seller Verification Status</h2>
            <p>Your seller application progress is shown below.</p>
        </div>

        <div class="seller-info">

            <div class="info">
                <small>Seller Name</small>
                <strong>{{ $seller->seller_name ?? 'Seller' }}</strong>
            </div>

            <div class="info">
                <small>Email</small>
                <strong>{{ $seller->email ?? '-' }}</strong>
            </div>

            <div class="info">
                <small>Application ID</small>
                <strong>#{{ $seller->id }}</strong>
            </div>

            <div class="info">
                <small>Current Step</small>
                <strong>{{ $seller->onboarding_step ?? 1 }} / 6</strong>
            </div>

        </div>

        @php
            $status = $seller->verification_status ?? 'unknown';

            $statusMap = [
                'pending_email' => [
                    'class' => 'pending',
                    'icon' => '✉️',
                    'title' => 'Email Verification Pending',
                    'message' => 'Please verify your registered seller email.'
                ],

                'email_verified' => [
                    'class' => 'pending',
                    'icon' => '📄',
                    'title' => 'Documents Required',
                    'message' => 'Your email is verified. Please complete your seller documents.'
                ],

                'documents_pending' => [
                    'class' => 'pending',
                    'icon' => '🪪',
                    'title' => 'Aadhaar Verification Pending',
                    'message' => 'Please complete Aadhaar verification.'
                ],

                'aadhaar_pending' => [
                    'class' => 'pending',
                    'icon' => '🔍',
                    'title' => 'Aadhaar Verification In Progress',
                    'message' => 'Your Aadhaar verification is being processed.'
                ],

                'pending_admin_review' => [
                    'class' => 'pending',
                    'icon' => '⏳',
                    'title' => 'Application Under Review',
                    'message' => 'Your seller application has been submitted and is waiting for admin approval.'
                ],

                'approved' => [
                    'class' => 'approved',
                    'icon' => '✅',
                    'title' => 'Application Approved',
                    'message' => 'Congratulations! Your seller application has been approved.'
                ],

                'rejected' => [
                    'class' => 'rejected',
                    'icon' => '❌',
                    'title' => 'Application Rejected',
                    'message' => $seller->rejection_reason
                        ? 'Reason: '.$seller->rejection_reason
                        : 'Your seller application was rejected.'
                ],

                'suspended' => [
                    'class' => 'suspended',
                    'icon' => '⚠️',
                    'title' => 'Seller Account Suspended',
                    'message' => 'Your seller account is currently suspended.'
                ],
            ];

            $currentStatus = $statusMap[$status] ?? [
                'class' => 'pending',
                'icon' => 'ℹ️',
                'title' => 'Verification Status',
                'message' => 'Your seller verification is being processed.'
            ];
        @endphp

        <div class="status {{ $currentStatus['class'] }}">

            <div class="status-icon">
                {{ $currentStatus['icon'] }}
            </div>

            <h3>
                {{ $currentStatus['title'] }}
            </h3>

            <p>
                {{ $currentStatus['message'] }}
            </p>

        </div>

        <div class="steps">

            <h3>Verification Progress</h3>

            <div class="step">
                <div class="circle {{ $seller->email_verified_at ? 'done' : '' }}">
                    {{ $seller->email_verified_at ? '✓' : '1' }}
                </div>

                <div class="step-text">
                    <strong>Email Verification</strong>
                    <small>
                        {{ $seller->email_verified_at ? 'Completed' : 'Pending' }}
                    </small>
                </div>
            </div>

            <div class="step">
                <div class="circle {{ $seller->business_certificate_path && $seller->aadhaar_document_path ? 'done' : '' }}">
                    {{ $seller->business_certificate_path && $seller->aadhaar_document_path ? '✓' : '2' }}
                </div>

                <div class="step-text">
                    <strong>Document Upload</strong>
                    <small>
                        {{ $seller->business_certificate_path && $seller->aadhaar_document_path ? 'Completed' : 'Pending' }}
                    </small>
                </div>
            </div>

            <div class="step">
                <div class="circle {{ $seller->aadhaar_verified_at ? 'done' : '' }}">
                    {{ $seller->aadhaar_verified_at ? '✓' : '3' }}
                </div>

                <div class="step-text">
                    <strong>Aadhaar Verification</strong>
                    <small>
                        {{ $seller->aadhaar_verified_at ? 'Completed' : 'Pending' }}
                    </small>
                </div>
            </div>

            <div class="step">
                <div class="circle {{ $status === 'pending_admin_review' || $status === 'approved' ? 'done' : '' }}">
                    {{ $status === 'pending_admin_review' || $status === 'approved' ? '✓' : '4' }}
                </div>

                <div class="step-text">
                    <strong>Admin Review</strong>
                    <small>
                        {{ $status === 'approved' ? 'Approved' : ($status === 'pending_admin_review' ? 'Under Review' : 'Pending') }}
                    </small>
                </div>
            </div>

            <div class="step">
                <div class="circle {{ $status === 'approved' ? 'done' : '' }}">
                    {{ $status === 'approved' ? '✓' : '5' }}
                </div>

                <div class="step-text">
                    <strong>Application Approval</strong>
                    <small>
                        {{ $status === 'approved' ? 'Approved' : 'Waiting for approval' }}
                    </small>
                </div>
            </div>

            <div class="step">
                <div class="circle {{ $seller->activation_verified_at ? 'done' : '' }}">
                    {{ $seller->activation_verified_at ? '✓' : '6' }}
                </div>

                <div class="step-text">
                    <strong>Seller Activation</strong>
                    <small>
                        {{ $seller->activation_verified_at ? 'Completed' : 'Pending' }}
                    </small>
                </div>
            </div>

        </div>

        <div class="actions">

            @if(!$seller->email_verified_at)
                <a href="{{ route('seller.verification.email') }}"
                   class="btn btn-primary">
                    Verify Email
                </a>
            @elseif(!$seller->business_certificate_path || !$seller->aadhaar_document_path)
                <a href="{{ route('seller.verification.documents') }}"
                   class="btn btn-primary">
                    Upload Documents
                </a>
            @elseif(!$seller->aadhaar_verified_at)
                <a href="{{ route('seller.verification.aadhaar') }}"
                   class="btn btn-primary">
                    Verify Aadhaar
                </a>
            @elseif($status === 'approved')
                <a href="{{ route('seller.activation') }}"
                   class="btn btn-primary">
                    Activate Seller Account
                </a>
            @endif

            <a href="{{ route('seller.login') }}"
               class="btn btn-secondary">
                Seller Login
            </a>

        </div>

    </div>

</div>

</body>
</html>