<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Aadhaar Verification | SmartBasket Premium</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Inter, Arial, sans-serif;
            color: #fff;
            background:
                radial-gradient(circle at top left, rgba(59,130,246,.20), transparent 35%),
                radial-gradient(circle at bottom right, rgba(168,85,247,.18), transparent 35%),
                #070b14;
            padding: 30px 18px;
        }

        .container {
            width: min(720px, 100%);
            margin: auto;
        }

        .brand {
            text-align: center;
            margin-bottom: 28px;
        }

        .brand h1 {
            margin: 0;
            font-size: 30px;
        }

        .brand span {
            color: #60a5fa;
        }

        .card {
            background: rgba(15,23,42,.9);
            border: 1px solid rgba(148,163,184,.18);
            border-radius: 24px;
            padding: 35px;
            box-shadow: 0 25px 80px rgba(0,0,0,.4);
        }

        h2 {
            margin: 0 0 8px;
            text-align: center;
            font-size: 28px;
        }

        .subtitle {
            text-align: center;
            color: #94a3b8;
            margin-bottom: 28px;
        }

        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        .success {
            background: rgba(34,197,94,.12);
            border: 1px solid rgba(34,197,94,.3);
            color: #86efac;
        }

        .error {
            background: rgba(239,68,68,.12);
            border: 1px solid rgba(239,68,68,.3);
            color: #fca5a5;
        }

        .info-box {
            background: rgba(30,41,59,.7);
            border: 1px solid rgba(148,163,184,.15);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-box h3 {
            margin-top: 0;
        }

        .info-box p {
            color: #cbd5e1;
            line-height: 1.6;
        }

        .seller-email {
            color: #60a5fa;
            font-weight: 700;
        }

        .field {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
        }

        input {
            width: 100%;
            padding: 15px;
            border-radius: 12px;
            border: 1px solid #334155;
            background: #0f172a;
            color: #fff;
            outline: none;
            font-size: 18px;
            letter-spacing: 3px;
        }

        input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59,130,246,.12);
        }

        .btn {
            width: 100%;
            padding: 15px;
            border: 0;
            border-radius: 12px;
            background: #3b82f6;
            color: white;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
        }

        .btn:hover {
            background: #2563eb;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 18px;
            color: #94a3b8;
            text-decoration: none;
        }

        .back:hover {
            color: white;
        }

        .documents {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 25px;
        }

        .document {
            padding: 16px;
            background: rgba(30,41,59,.55);
            border-radius: 12px;
        }

        .document strong {
            display: block;
            margin-bottom: 5px;
        }

        .verified {
            color: #4ade80;
        }

        @media(max-width: 600px) {
            .card {
                padding: 22px;
            }

            .documents {
                grid-template-columns: 1fr;
            }
        }
    </style>

</head>

<body>

<div class="container">

    <div class="brand">
        <h1>SMART BASKET <span>PREMIUM</span></h1>
    </div>

    <div class="card">

        <h2>Aadhaar Verification</h2>

        <p class="subtitle">
            Step 3 of 6 — Verify your identity
        </p>

        @if(session('success'))
            <div class="alert success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert error">
                {{ session('error') }}
            </div>
        @endif

        @if($errors->any())
            <div class="alert error">
                <ul style="margin:0;padding-left:20px;">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="info-box">

            <h3>Identity Verification</h3>

            <p>
                Enter the 12-digit Aadhaar number associated with
                the Aadhaar document uploaded for this seller account.
            </p>

            <p>
                Seller:
                <span class="seller-email">
                    {{ $seller->email }}
                </span>
            </p>

        </div>

        <div class="documents">

            <div class="document">
                <strong>Business Certificate</strong>

                @if($seller->business_certificate_path)
                    <span class="verified">✓ Uploaded</span>
                @else
                    <span>Not uploaded</span>
                @endif
            </div>

            <div class="document">
                <strong>Aadhaar Document</strong>

                @if($seller->aadhaar_document_path)
                    <span class="verified">✓ Uploaded</span>
                @else
                    <span>Not uploaded</span>
                @endif
            </div>

        </div>

        @if(!$seller->aadhaar_verified_at)

            <form
                method="POST"
                action="{{ route('seller.verification.aadhaar.verify') }}"
            >

                @csrf

                <div class="field">

                    <label for="aadhaar_number">
                        Aadhaar Number
                    </label>

                    <input
                        id="aadhaar_number"
                        type="text"
                        name="aadhaar_number"
                        inputmode="numeric"
                        maxlength="12"
                        minlength="12"
                        pattern="[0-9]{12}"
                        placeholder="Enter 12-digit Aadhaar number"
                        value="{{ old('aadhaar_number') }}"
                        required
                    >

                </div>

                <button type="submit" class="btn">
                    Verify Aadhaar & Continue
                </button>

            </form>

        @else

            <div class="alert success">
                ✓ Aadhaar verification completed successfully.
            </div>

            <a
                href="{{ route('seller.verification.status') }}"
                class="btn"
                style="display:block;text-align:center;text-decoration:none;"
            >
                Continue to Application Status
            </a>

        @endif

        <a
            href="{{ route('seller.verification.documents') }}"
            class="back"
        >
            ← Back to Documents
        </a>

    </div>

</div>

</body>
</html>