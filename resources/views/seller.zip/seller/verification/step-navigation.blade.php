@php
    $currentStep = (int) ($seller->onboarding_step ?? 1);

    if ($seller->email_verified_at && $currentStep < 2) {
        $currentStep = 2;
    }

    if (
        $seller->business_certificate_path &&
        $seller->aadhaar_document_path &&
        $currentStep < 3
    ) {
        $currentStep = 3;
    }

    if ($seller->aadhaar_verified_at && $currentStep < 4) {
        $currentStep = 4;
    }

    if (
        $seller->verification_status ===
        \App\Models\SellerProfile::STATUS_PENDING_ADMIN_REVIEW
    ) {
        $currentStep = 5;
    }

    if (
        $seller->verification_status ===
        \App\Models\SellerProfile::STATUS_APPROVED
    ) {
        $currentStep = 6;
    }

    $steps = [
        1 => [
            'title' => 'Email',
            'icon' => '✉',
            'route' => 'seller.verification.email',
        ],
        2 => [
            'title' => 'Documents',
            'icon' => '▣',
            'route' => 'seller.verification.documents',
        ],
        3 => [
            'title' => 'Aadhaar',
            'icon' => '◉',
            'route' => 'seller.verification.aadhaar',
        ],
        4 => [
            'title' => 'Review',
            'icon' => '✓',
            'route' => 'seller.verification.review',
        ],
        5 => [
            'title' => 'Approval',
            'icon' => '◆',
            'route' => 'seller.verification.status',
        ],
        6 => [
            'title' => 'Activation',
            'icon' => '★',
            'route' => 'seller.activation',
        ],
    ];
@endphp

<style>
    .sb-wizard {
        width: 100%;
        margin-bottom: 28px;
    }

    .sb-wizard-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        margin-bottom: 20px;
    }

    .sb-wizard-brand {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .sb-wizard-logo {
        width: 44px;
        height: 44px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        background:
            linear-gradient(
                135deg,
                #ffffff,
                #d7d7d7
            );
        color: #111;
        font-weight: 900;
        box-shadow:
            0 10px 30px rgba(255,255,255,.12);
    }

    .sb-wizard-title {
        color: #fff;
        font-size: 18px;
        font-weight: 800;
        letter-spacing: .3px;
    }

    .sb-wizard-subtitle {
        color: rgba(255,255,255,.5);
        font-size: 12px;
        margin-top: 3px;
    }

    .sb-step-count {
        color: rgba(255,255,255,.55);
        font-size: 13px;
        white-space: nowrap;
    }

    .sb-progress {
        height: 5px;
        width: 100%;
        background: rgba(255,255,255,.08);
        border-radius: 100px;
        overflow: hidden;
        margin-bottom: 22px;
    }

    .sb-progress-fill {
        height: 100%;
        border-radius: inherit;
        background:
            linear-gradient(
                90deg,
                #ffffff,
                #8d8d8d
            );
        transition: width .4s ease;
    }

    .sb-steps {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 8px;
    }

    .sb-step {
        position: relative;
        min-width: 0;
    }

    .sb-step-link {
        text-decoration: none;
        display: block;
        padding: 12px 8px;
        border-radius: 16px;
        border: 1px solid rgba(255,255,255,.08);
        background: rgba(255,255,255,.035);
        transition: .25s ease;
    }

    .sb-step-link:hover {
        background: rgba(255,255,255,.075);
        border-color: rgba(255,255,255,.18);
        transform: translateY(-2px);
    }

    .sb-step.active .sb-step-link {
        background: rgba(255,255,255,.10);
        border-color: rgba(255,255,255,.28);
        box-shadow:
            0 10px 35px rgba(0,0,0,.2);
    }

    .sb-step.completed .sb-step-link {
        border-color: rgba(255,255,255,.16);
    }

    .sb-step-number {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin: 0 auto 7px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255,255,255,.07);
        color: rgba(255,255,255,.65);
        font-size: 12px;
        font-weight: 800;
    }

    .sb-step.active .sb-step-number,
    .sb-step.completed .sb-step-number {
        background: #fff;
        color: #111;
    }

    .sb-step-title {
        text-align: center;
        color: rgba(255,255,255,.55);
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .sb-step.active .sb-step-title {
        color: #fff;
    }

    .sb-navigation {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-top: 24px;
    }

    .sb-nav-btn {
        min-width: 125px;
        min-height: 44px;
        border-radius: 13px;
        padding: 10px 18px;
        border: 1px solid rgba(255,255,255,.12);
        background: rgba(255,255,255,.055);
        color: #fff;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 800;
        transition: .25s ease;
        cursor: pointer;
    }

    .sb-nav-btn:hover {
        background: rgba(255,255,255,.11);
        border-color: rgba(255,255,255,.25);
        transform: translateY(-1px);
    }

    .sb-nav-btn.primary {
        background: #fff;
        color: #111;
        border-color: #fff;
    }

    .sb-nav-btn.primary:hover {
        background: #e8e8e8;
    }

    .sb-nav-btn.disabled {
        opacity: .35;
        pointer-events: none;
    }

    .sb-edit-note {
        text-align: center;
        color: rgba(255,255,255,.42);
        font-size: 11px;
        margin-top: 10px;
    }

    @media (max-width: 760px) {

        .sb-wizard-header {
            align-items: flex-start;
        }

        .sb-steps {
            grid-template-columns: repeat(3, 1fr);
            gap: 7px;
        }

        .sb-step-link {
            padding: 10px 5px;
        }

        .sb-navigation {
            position: sticky;
            bottom: 10px;
            z-index: 20;
            padding: 10px;
            border-radius: 17px;
            background: rgba(18,18,18,.88);
            backdrop-filter: blur(18px);
            border: 1px solid rgba(255,255,255,.08);
        }

        .sb-nav-btn {
            min-width: 0;
            flex: 1;
        }
    }
</style>

<div class="sb-wizard">

    <div class="sb-wizard-header">

        <div class="sb-wizard-brand">

            <div class="sb-wizard-logo">
                SB
            </div>

            <div>
                <div class="sb-wizard-title">
                    Seller Partner Program
                </div>

                <div class="sb-wizard-subtitle">
                    SMART BASKET PREMIUM
                </div>
            </div>

        </div>

        <div class="sb-step-count">
            Step {{ min($currentStep, 6) }} of 6
        </div>

    </div>

    <div class="sb-progress">

        <div
            class="sb-progress-fill"
            style="width: {{ (min($currentStep, 6) / 6) * 100 }}%"
        ></div>

    </div>

    <div class="sb-steps">

        @foreach($steps as $number => $step)

            @php
                $completed = $number < $currentStep;
                $active = $number === $currentStep;

                $allowed = $number <= $currentStep;
            @endphp

            <div
                class="
                    sb-step
                    {{ $active ? 'active' : '' }}
                    {{ $completed ? 'completed' : '' }}
                "
            >

                @if($allowed)

                    <a
                        href="{{ route($step['route']) }}"
                        class="sb-step-link"
                        title="Open {{ $step['title'] }} step"
                    >

                        <div class="sb-step-number">

                            @if($completed)
                                ✓
                            @else
                                {{ $number }}
                            @endif

                        </div>

                        <div class="sb-step-title">
                            {{ $step['title'] }}
                        </div>

                    </a>

                @else

                    <div class="sb-step-link">

                        <div class="sb-step-number">
                            {{ $number }}
                        </div>

                        <div class="sb-step-title">
                            {{ $step['title'] }}
                        </div>

                    </div>

                @endif

            </div>

        @endforeach

    </div>

    <div class="sb-navigation">

        @if($currentStep > 1)

            <a
                href="{{ route('seller.verification.back') }}"
                class="sb-nav-btn"
            >
                ← Back
            </a>

        @else

            <span
                class="sb-nav-btn disabled"
            >
                ← Back
            </span>

        @endif


        @if($currentStep < 4)

            <a
                href="{{ route('seller.verification.next') }}"
                class="sb-nav-btn primary"
            >
                Next →
            </a>

        @elseif($currentStep === 4)

            <a
                href="{{ route('seller.verification.next') }}"
                class="sb-nav-btn primary"
            >
                Review →
            </a>

        @elseif($currentStep === 5)

            <a
                href="{{ route('seller.verification.status') }}"
                class="sb-nav-btn primary"
            >
                Application Status →
            </a>

        @elseif($currentStep === 6)

            <a
                href="{{ route('seller.activation') }}"
                class="sb-nav-btn primary"
            >
                Activate →
            </a>

        @endif

    </div>

    <div class="sb-edit-note">
        ✓ Completed steps can be opened again and edited.
    </div>

</div>